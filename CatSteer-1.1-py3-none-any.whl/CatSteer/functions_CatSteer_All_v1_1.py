
#functions_CatSteer

# import s2sphere
# import pandas as pd
# import folium
# import geopandas as gpd
# from folium.plugins import Geocoder
# import numpy as np


#List of functions defined:

# Generate Data:
#   LOB_selection
#   summarise_by_region

# Add layers to Map:
#   APTP_layer
#   Action_APTP_layer
#   Action_accumulation_layer
#   summary_layer

# Standalone:
#   add_hazard_map
#   add_geocoder

#temp
#   summarise_by_region_S2

# import folium
# from folium import LinearColormap
# from folium.plugins import HeatMap
# import pandas as pd
# import numpy as np




def test():
    pass

def list_functions_catsteer():
    return [
        'list_functions', 
        "get_cell_id_from_token",
        "get_parent_cell_token_level_X",
        "add_hazard_map",
        "add_hazard_map_bins",
        "add_geocoder",
        "LOB_selection",
        "summarise_by_region",
        "APTP_layer",
        "variable_layer",
        "Action_APTP_layer",
        "Action_ELAP_layer",
        "summary_layer",
        "summary_layer_region",
        "Action_accumulation_layer",
        "Action_accumulation_layer_region",
        "create_inforce_s2",
        "create_inforce_region",
        "Action_accumulation_layer_CRESTA"
    ]


########################### CORE #################



def save(base_map, html_save):
    base_map_dup = copy.deepcopy(base_map)
    folium.LayerControl(collapsed=False).add_to(base_map_dup)
    base_map_dup.save(html_save)



########################### S2  #################


def get_cell_id_from_token(s2_token):
    cell_id = s2sphere.CellId.from_token(s2_token) 
    return cell_id.id()  


def get_parent_cell_token_level_X(s2_token, s2_level):
    cell_id = s2sphere.CellId.from_token(s2_token) 
    parent_cell_id = cell_id.parent(s2_level) 
    return parent_cell_id.to_token()  




########################### MAPS  #################



# Add a search box for addresses
def add_geocoder(map_object):
    geocoder = Geocoder()
    map_object.add_child(geocoder)
    return map_object



########################### STEER #################




# base_map, grid=gdf_s2_scenario, peril_label='AP_initial', show=True, variable_name='AP_initial')
def add_hazard_map(base_map, grid, peril_label, show, variable_name, tooltips, shading_percentile):
    
    grid['INDEX'] = grid[variable_name]
    grid[variable_name] = pd.to_numeric(grid[variable_name])
    grid[variable_name] = grid[variable_name].fillna(0)
    grid = grid.dropna(subset=['geometry'])  
    grid['CAPPED'] = grid[variable_name].clip(upper=grid[variable_name].quantile(shading_percentile))
    grid = grid[['geometry', variable_name, 'CAPPED']]
    layer = folium.Choropleth(
        geo_data=grid.to_json(),
        data=grid,
        name=peril_label,
        columns=[variable_name, 'CAPPED'],
        key_on=rf'feature.properties.{variable_name}',
        fill_color='YlOrRd',
        fill_opacity=0.7,
        line_opacity=0.2,
        show=show,
        legend_name=None 
        ).add_to(base_map)

    if tooltips==True:
        folium.GeoJson(
            grid,
            style_function=lambda feature: {
                'fillColor': '#ffffff',
                'color': '#000000',
                'weight': 0.5,
                'fillOpacity': 0,
            },
            highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
            tooltip=folium.GeoJsonTooltip(
                fields=[variable_name],
                aliases=[ peril_label],
                localize=True,
                sticky=True,
                labels=True,
                style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
            )
        ).add_to(layer)

    return layer



# initial_inforce_AP = add_hazard_map_bins(base_map, grid=gdf_s2_scenario, 'AP_initial', False, 'AP_initial', True, 6, 0.995)
# base_map, grid=gdf_s2_scenario, peril_label='AP_initial', show=True, variable_name='AP_initial')
def add_hazard_map_bins(base_map, grid, region_select, peril_label, show, variable_name, tooltips, bins, min_percentile, cap_percentile, colour_scale):
    
    grid[variable_name] = pd.to_numeric(grid[variable_name])
    grid[variable_name] = grid[variable_name].fillna(0)
    grid = grid.dropna(subset=['geometry'])  


    top_bin_threshold = grid[variable_name].quantile(cap_percentile)
    bottom_bin_threshold = grid[variable_name].quantile(min_percentile)

    grid['BINS'] = np.where(grid[variable_name] > top_bin_threshold, bins, 
                    np.where(grid[variable_name] < bottom_bin_threshold, 1, np.nan))

    remaining_rows = grid[grid['BINS'].isna()]
    remaining_bins = pd.qcut(remaining_rows[variable_name], q=bins-2, labels=False, duplicates='drop') + 2
    grid.loc[remaining_rows.index, 'BINS'] = remaining_bins

    grid['BINS'] = pd.to_numeric(grid['BINS'])
    grid['BINS'] = grid['BINS'].fillna(1)


   
    grid = grid[['geometry', variable_name, 'BINS', region_select]]
    layer = folium.Choropleth(
        geo_data=grid.to_json(),
        data=grid,
        name=peril_label,
        columns=[region_select, 'BINS'],
        key_on=rf'feature.properties.{region_select}',
        fill_color=colour_scale,  # Changed to yellow to red color scheme
        fill_opacity=0.7,
        line_opacity=0.2,
        show=show,
        legend_name=None 
        ).add_to(base_map)

    if tooltips==True:
        folium.GeoJson(
            grid,
            style_function=lambda feature: {
                'fillColor': '#ffffff',
                'color': '#000000',
                'weight': 0.5,
                'fillOpacity': 0,
            },
            highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
            tooltip=folium.GeoJsonTooltip(
                fields=[variable_name],
                aliases=[ peril_label],
                localize=True,
                sticky=True,
                labels=True,
                style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
            )
        ).add_to(layer)

    return layer



def add_hazard_map_bins_alt(base_map, grid, region_select, peril_label, show, variable_name, tooltips, bins, min_percentile, cap_percentile):
    
    grid[variable_name] = pd.to_numeric(grid[variable_name])
    grid[variable_name] = grid[variable_name].fillna(0)
    grid = grid.dropna(subset=['geometry'])  

    top_bin_threshold = grid[variable_name].quantile(cap_percentile)
    grid['BINS'] = np.where(grid[variable_name] > top_bin_threshold, bins, np.nan)
    remaining_rows = grid[grid['BINS'].isna()]
    remaining_bins = pd.qcut(remaining_rows[variable_name], q=bins-1, labels=False, duplicates='drop') + 1
    grid.loc[remaining_rows.index, 'BINS'] = remaining_bins
    grid['BINS'] = pd.to_numeric(grid['BINS'])
    grid['BINS'] = grid['BINS'].fillna(1)
   
    grid = grid[['geometry', variable_name, 'BINS', region_select]]

    # Create the color map from red (negative) to white (zero) to green (positive)
    colormap = LinearColormap(['red', 'white', 'green'], vmin=grid[variable_name].min(), vmax=grid[variable_name].max())
    
    layer = folium.Choropleth(
        geo_data=grid.to_json(),
        data=grid,
        name=peril_label,
        columns=[region_select, variable_name],
        key_on=rf'feature.properties.{region_select}',
        fill_color='YlGnBu',  # Remove this if you're using a custom colormap.
        fill_opacity=0.7,
        line_opacity=0.2,
        show=show,
        legend_name=None,
        threshold_scale=[grid[variable_name].min(), 0, grid[variable_name].max()]  # Ensure scale is from negative to positive
    ).add_to(base_map)

    # Add the custom colormap legend
    colormap.caption = 'Value Range'
    colormap.add_to(base_map)

    if tooltips == True:
        folium.GeoJson(
            grid,
            style_function=lambda feature: {
                'fillColor': colormap(feature['properties'][variable_name]),  # Use the colormap to color features
                'color': '#000000',
                'weight': 0.5,
                'fillOpacity': 0.7,
            },
            highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
            tooltip=folium.GeoJsonTooltip(
                fields=[variable_name],
                aliases=[peril_label],
                localize=True,
                sticky=True,
                labels=True,
                style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
            )
        ).add_to(layer)

    return layer





def LOB_selection(df, LOB):

    df['LOB_DETAIL1'] = df['LOB_DETAIL1'].str.upper()

    if LOB != 'All':
        df_filtered = df[df['LOB_DETAIL1'] == LOB]
    else:
        df_filtered = df[df['LOB_DETAIL1'] != 'SCIA']
        #df_filtered = df

    df_filtered['TOTAL/AP'] = ((df_filtered['EL'] + df_filtered['RE']) / df_filtered['AP']) 
    print(df_filtered['TOTAL/AP'].describe()) 
    df_filtered['TOTAL/AP'].hist(bins=100, range=(0, 1.0))

    return df_filtered


#add a Target parameter and do the target summarisation here?
# aptp min and max just for colouring in graph scales
def summarise_by_region(df, region, aptp_label_min, aptp_label_max):
    
    if rf'{region}_NAME' not in df.columns:
        df[rf'{region}_NAME'] = "-"

    df_summary = df.groupby([region, rf'{region}_NAME']).agg({
    # df_summary = df.groupby([region]).agg({
        'RISK_COUNT': 'sum',
        'SI': 'sum',
        'AP': 'sum', 
        'TP': 'sum', 
        'EL_EQ': 'sum',
        'EL_CY': 'sum',
        'EL_BF': 'sum',
        'EL_HL': 'sum', 
        'EL_ST': 'sum', 
        'EL_FL': 'sum',
        'RE_EQ': 'sum', 
        'RE_CY': 'sum',
        'RE_BF': 'sum', 
        'RE_HL': 'sum', 
        'RE_ST': 'sum',
        'RE_FL': 'sum',
        'M_RE_EQ': 'sum', 
        'M_RE_CY': 'sum',
        'M_RE_BF': 'sum', 
        'M_RE_HL': 'sum', 
        'M_RE_ST': 'sum',
        'M_RE_FL': 'sum'
    }).reset_index()

    df_summary['EQ'] = ((df_summary['EL_EQ'] + df_summary['RE_EQ']) / df_summary['AP']) * 100
    df_summary['CY'] = ((df_summary['EL_CY'] + df_summary['RE_CY']) / df_summary['AP']) * 100
    df_summary['BF'] = ((df_summary['EL_BF'] + df_summary['RE_BF']) / df_summary['AP']) * 100
    df_summary['HL'] = ((df_summary['EL_HL'] + df_summary['RE_HL']) / df_summary['AP']) * 100
    df_summary['ST'] = ((df_summary['EL_ST'] + df_summary['RE_ST']) / df_summary['AP']) * 100
    df_summary['FL'] = ((df_summary['EL_FL'] + df_summary['RE_FL']) / df_summary['AP']) * 100
    df_summary['Accumulation'] = ((df_summary['RE_EQ'] + df_summary['RE_CY'] + df_summary['RE_BF'] + df_summary['RE_HL'] + df_summary['RE_ST'] + df_summary['RE_FL']) / df_summary['AP']) * 100
    df_summary['Cat Exposure'] = ((df_summary['EL_EQ'] + df_summary['EL_CY'] + df_summary['EL_BF'] + df_summary['EL_HL'] + df_summary['EL_ST'] + df_summary['EL_FL']) / df_summary['AP']) * 100
    df_summary['Pricing Strength (AP/TP)'] = (df_summary['AP'] / df_summary['TP']) * 100
    df_summary['Marginal_accumulation'] = ((df_summary['M_RE_EQ'] + df_summary['M_RE_CY'] + df_summary['M_RE_BF'] + df_summary['M_RE_HL'] + df_summary['M_RE_ST'] + df_summary['M_RE_FL']) / df_summary['AP']) * 100
    df_summary['AP/TP'] = df_summary['AP'] / df_summary['TP']

    df_summary['TOTAL_AP'] = df_summary['Cat Exposure'] + df_summary['Accumulation']

    df_summary['EL'] = (df_summary['EL_EQ'] + df_summary['EL_CY'] + df_summary['EL_BF'] + df_summary['EL_HL'] + df_summary['EL_ST'] + df_summary['EL_FL'])

    # AP/TP to numeric
    df_summary['AP/TP'] = pd.to_numeric(df_summary['AP/TP'])
    df_summary['TP/AP'] = 1/df_summary['AP/TP']

    df_summary['AP/TP_LABEL'] = df_summary['AP/TP'].apply(lambda x: max(x, aptp_label_min))
    df_summary['AP/TP_LABEL'] = df_summary['AP/TP'].apply(lambda x: min(x, aptp_label_max))

    # Ensure there are no missing values in AP/TP
    df_summary['AP/TP'] = df_summary['AP/TP'].fillna(1)
    #show missing values
    df_summary.isnull().sum()



    #Create variable called TARGET_PERILS that lists all perils that have HIGH exposure
    df_summary['Max_Peril'] = df_summary[['EQ', 'CY', 'BF', 'HL', 'ST', 'FL']].idxmax(axis=1)
    df_summary['Max_Peril_List'] = df_summary[['EQ', 'CY', 'BF', 'HL', 'ST', 'FL']].apply(lambda x: ', '.join(x[(x.index != 'ST') & (x > 12) | (x.index == 'ST') & (x > 19)].index), axis=1)

    #formatting
    df_summary['RISK_COUNT'] = df_summary['RISK_COUNT'].map(lambda x: f"{x:1.1f}K")
    df_summary['SI'] = df_summary['SI'].map(lambda x: f"${x/1e3:1.2f}B")
    df_summary['AP_LABEL'] = df_summary['AP'].map(lambda x: f"${x/1e6:1.1f}M")
    df_summary['EQ'] = df_summary['EQ'].map(lambda x: f"{x:.0f}%") + df_summary['EQ'].apply(lambda x: ' HIGH' if x > 12 else '')
    df_summary['CY'] = df_summary['CY'].map(lambda x: f"{x:.0f}%")  + df_summary['CY'].apply(lambda x: ' HIGH' if x > 12 else '')
    df_summary['BF'] = df_summary['BF'].map(lambda x: f"{x:.0f}%") + df_summary['BF'].apply(lambda x: ' HIGH' if x > 12 else '')
    df_summary['HL'] = df_summary['HL'].map(lambda x: f"{x:.0f}%") + df_summary['HL'].apply(lambda x: ' HIGH' if x > 12 else '')
    df_summary['ST'] = df_summary['ST'].map(lambda x: f"{x:.0f}%") + df_summary['ST'].apply(lambda x: ' HIGH' if x > 19 else '')
    df_summary['FL'] = df_summary['FL'].map(lambda x: f"{x:.0f}%") + df_summary['FL'].apply(lambda x: ' HIGH' if x > 12 else '')
    df_summary['Accumulation'] = df_summary['Accumulation'].map(lambda x: f"{x:.0f}%") + df_summary['Accumulation'].apply(lambda x: ' HIGH' if x > 8 else '')
    df_summary['Marginal_accumulation'] = df_summary['Marginal_accumulation'].map(lambda x: f"{x:.0f}%") + df_summary['Marginal_accumulation'].apply(lambda x: ' HIGH' if x > 15 else '')
    df_summary['Cat Exposure'] = df_summary['Cat Exposure'].map(lambda x: f"{x:.0f}%") 
    df_summary['Pricing Strength (AP/TP)'] = df_summary['Pricing Strength (AP/TP)'].map(lambda x: f"{x:.0f}%")

    #now create a gdf from it
    region_df_summary = df_summary

    gdf_region = eval(rf'gdf_{region}')
    #merge
    gdf_region[region] = gdf_region[region].astype(str)
    region_df_summary[region] = region_df_summary[region].astype(str)
    summary_gdf_region = gdf_region.merge(region_df_summary, left_on=region, right_on=region, how='inner')
    print("missings from SA3 merge:", summary_gdf_region.isnull().sum())


    

    return region_df_summary, summary_gdf_region


def APTP_layer(gdf_overall, region):
       
    if rf'{region}_NAME' not in df.columns:
        df_acc[rf'{region}_NAME'] = "-"
    


    choropleth = folium.Choropleth(
        geo_data=gdf_overall,
        data=gdf_overall,
        columns=[region, 'AP/TP'],
        key_on=f'feature.properties.{region}',
        fill_color='RdYlGn',  
        fill_opacity=0.8,
        line_opacity=0.2,
        legend_name=None, #'Total AP/TP by SA3',
        name='Overall AP/TP',
        show=False
    )
    choropleth.layer_name = 'Overall AP/TP by SA3'

    gdf_overall['BLANK'] = ' '
    folium.GeoJson(
        gdf_overall,  
        name=region,
        style_function=lambda feature: {
            'fillColor': '#ffffff',
            'color': '#000000',
            'weight': 0.5,
            'fillOpacity': 0,
        },
        highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
        tooltip=folium.GeoJsonTooltip(
            fields=['BLANK','BLANK',region, rf'{region}_NAME', 'RISK_COUNT', 'SI', 'AP', 'BLANK','BLANK','Pricing Strength (AP/TP)', 'Cat Exposure (CAT/AP)', 'Accumulation (RE/AP)',  'BLANK','BLANK', 'EQ', 'CY', 'BF', 'HL', 'ST', 'FL'],
            aliases=[
                'Current Inforce Metrics',
                ' ',
                'Region:', 
                'Region Name:', 
                'Risk Count:',
                'SI:',
                'AP:',
                ' ',
                ' ',
                'Pricing Strength (AP/TP):',
                'Cat Exposure:',
                'Accumulation:',
                ' ',
                ' ',
                'EQ:', 
                'CY:',
                'BF:', 
                'HL:',
                'ST:', 
                'FL:',

            ],
            localize=True,
            sticky=True,
            labels=True,
            style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;"),
            
        )
    ).add_to(choropleth)

    return choropleth


def variable_layer(gdf, region, variable):
    
    choropleth = folium.Choropleth(
        geo_data=gdf,
        data=gdf,
        columns=[region, variable],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',  
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name=None, 
        nan_fill_color='transparent', 
        show=False
    )
    choropleth.layer_name = variable

    
    folium.GeoJson(
        gdf,  # this has to be a geodataframe with the geometry
        name=variable,
        style_function=lambda _: {
            'fillColor': '#ffffff',
            'color': '#000000',
            'weight': 0.5,
            'fillOpacity': 0,
        },
        highlight_function=lambda _: {'weight': 3, 'color': 'blue'},
        tooltip=folium.GeoJsonTooltip(
            fields=[variable, region],
            aliases=[variable, region],
            localize=True,
            sticky=True,
            labels=True,
            style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
        )
    ).add_to(choropleth)

    return choropleth


def Action_APTP_layer(df, EL_or_TOTAL, Marginal, Layer_APTP_Threshold, Layer_Total_Peril_Threshold, Layer_AP_Threshold, region):

    if rf'{region}_NAME' not in df.columns:
        df_acc[rf'{region}_NAME'] = "-"


    if EL_or_TOTAL == 'EL':
        df['AP/TP'] = df['AP']/df['EL']

    if EL_or_TOTAL == 'TOTAL':
        df['TOTAL'] = df['EL']  + df['RE'] 
        df['AP/TP'] = df['AP']/df['TOTAL']    


    if Marginal == 'Yes':
        df_target = df[df['M_AP/TP'] < Layer_APTP_Threshold ]
    else:
        df_target = df[df['AP/TP'] < Layer_APTP_Threshold  ]

    print("Target policies TOTAL/AP")
    # print(df_target['TOTAL/AP'].describe()) 
    df_target['TOTAL/AP'].hist(bins=100, range=(0, 1.0))

    # print("Target policies EL/AP")
    # # print(df_target['TOTAL/AP'].describe())
    # df_target['EL/AP'] =  
    # df_target['EL/AP'].hist(bins=100, range=(0, 1.0))


    if Layer_Total_Peril_Threshold == 'No':
        df_target = df_target
    else:
        df_target = df_target[df_target['TOTAL/AP'] > Layer_Total_Peril_Threshold  ]


    df_region_summary_target, gdf_action_aptp = summarise_by_region(df_target, region, 0.8, 1.0)


    # if LOB == 'Home':
    #     df_summary = df_summary[df_summary['AP'] > 1000000]
    # elif LOB == 'All':
    #     df_summary = df_summary[df_summary['AP'] > 1000000]
    # else:
    #     df_summary = df_summary[df_summary['AP'] > 500000]

    # for a separate list: keep rows in df where the SA3 is in the list of SA3 in df_summary
    df_target = df_target[df_target[region].isin(df_region_summary_target[region])]
    print("row latlongs to plot#: ", len(df_target))

    gdf_action_aptp_all = gdf_action_aptp
    
    gdf_action_aptp = gdf_action_aptp[gdf_action_aptp['AP'] >= Layer_AP_Threshold]

    print("Total AP in Action Segment APTP: ", gdf_action_aptp['AP'].sum())

    target_choropleth = folium.Choropleth(
        geo_data=gdf_action_aptp,
        data=gdf_action_aptp,
        columns=[region, 'AP'],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',  
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name=None, #'AP by SA3',
        nan_fill_color='transparent', 
        show=False
    )
    target_choropleth.layer_name = 'Action Segment: underpriced risk (shading: GWP)'
    
    gdf_action_aptp['BLANK'] = ' '
    folium.GeoJson(
        gdf_action_aptp,  
        name=region,
        style_function=lambda feature: {
            'fillColor': '#ffffff',
            'color': '#000000',
            'weight': 0.5,
            'fillOpacity': 0,
        },
        highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
        tooltip=folium.GeoJsonTooltip(
            fields=['BLANK','BLANK',region, rf'{region}_NAME', 'RISK_COUNT', 'SI', 'AP_LABEL', 'BLANK','BLANK', 'Pricing Strength (AP/TP)', 'Cat Exposure', 'Accumulation', 
                    #'Marginal_accumulation',  
                    'BLANK','BLANK',
                    'EQ', 'CY', 'BF', 'HL', 'ST', 'FL'],
            aliases=[
                'Action Segment Metrics',' ',
                'Region:', 
                'Region Name:', 
                'Risk Count:',
                'SI:',
                'AP:', 
                ' ',
                ' ',
                'Pricing Strength (AP/TP):',
                'Cat Exposure:',
                'Accumulation:',
                ' ',
                ' ',
                #'Marginal Accumulation:',
                'EQ:', 
                'CY:',
                'BF:', 
                'HL:',
                'ST:', 
                'FL:',
            ],
            localize=True,
            sticky=True,  
            labels=True,
            style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;"),
        )
    ).add_to(target_choropleth)

    return target_choropleth, gdf_action_aptp_all



# not used
def Action_ELAP_layer(df, EL_or_TOTAL, Action_Threshold, Layer_AP_Threshold, region):

    if rf'{region}_NAME' not in df.columns:
        df_acc[rf'{region}_NAME'] = "-"

    df['EL/AP'] = (df['EL'] / df['AP']).fillna(0)
    
    if EL_or_TOTAL == 'EL':
        df_target = df[df['EL/AP'] < Action_Threshold  ]
    else:
        df_target = df[df['TOTAL/AP'] < Action_Threshold  ]

    print("Target policies TOTAL/AP")
    print(df_target['TOTAL/AP'].describe()) 
    df_target['TOTAL/AP'].hist(bins=100, range=(0, 1.0))


    # if Layer_Total_Peril_Threshold == 'No':
    #     df_target = df_target
    # else:
    #     df_target = df_target[df_target['TOTAL/AP'] > Layer_Total_Peril_Threshold  ]


    df_region_summary_target, gdf_action_aptp = summarise_by_region(df_target, region, 0.8, 1.0)


    # if LOB == 'Home':
    #     df_summary = df_summary[df_summary['AP'] > 1000000]
    # elif LOB == 'All':
    #     df_summary = df_summary[df_summary['AP'] > 1000000]
    # else:
    #     df_summary = df_summary[df_summary['AP'] > 500000]

    # for a separate list: keep rows in df where the SA3 is in the list of SA3 in df_summary
    df_target = df_target[df_target[region].isin(df_region_summary_target[region])]
    print("row latlongs to plot#: ", len(df_target))

    gdf_action_aptp_all = gdf_action_aptp
    
    gdf_action_aptp = gdf_action_aptp[gdf_action_aptp['AP'] >= Layer_AP_Threshold]

    print("Total AP in Action Segment APTP: ", gdf_action_aptp['AP'].sum())

    target_choropleth = folium.Choropleth(
        geo_data=gdf_action_aptp,
        data=gdf_action_aptp,
        columns=[region, 'AP'],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',  
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name=None, #'AP by SA3',
        nan_fill_color='transparent', 
        show=False
    )
    target_choropleth.layer_name = 'Action Segment: underpriced risk (shading: GWP)'
    
    gdf_action_aptp['BLANK'] = ' '
    folium.GeoJson(
        gdf_action_aptp,  
        name=region,
        style_function=lambda feature: {
            'fillColor': '#ffffff',
            'color': '#000000',
            'weight': 0.5,
            'fillOpacity': 0,
        },
        highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
        tooltip=folium.GeoJsonTooltip(
            fields=['BLANK','BLANK',region, rf'{region}_NAME', 'RISK_COUNT', 'SI', 'AP_LABEL', 'BLANK','BLANK', 'Pricing Strength (AP/TP)', 'Cat Exposure', 'Accumulation', 
                    #'Marginal_accumulation',  
                    'BLANK','BLANK',
                    'EQ', 'CY', 'BF', 'HL', 'ST', 'FL'],
            aliases=[
                'Action Segment Metrics',' ',
                'Region:', 
                'Region Name:', 
                'Risk Count:',
                'SI:',
                'AP:', 
                ' ',
                ' ',
                'Pricing Strength (AP/TP):',
                'Cat Exposure:',
                'Accumulation:',
                ' ',
                ' ',
                #'Marginal Accumulation:',
                'EQ:', 
                'CY:',
                'BF:', 
                'HL:',
                'ST:', 
                'FL:',
            ],
            localize=True,
            sticky=True,  
            labels=True,
            style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;"),
        )
    ).add_to(target_choropleth)

    return target_choropleth, gdf_action_aptp_all


def summary_layer(gdf_overall, gdf_action_aptp, gdf_action_acc, gdf_take_up, Case_APTP_Condition, Target_AP_Threshold, Acc_EQ_Threshold, Take_Up_condition, region, region_name ):
    
    ### NEED gpd_overall (gdf_overall) AND target (aptp filter, target_inf ) merged onto that
    ### SUMMARISE JUST THE TARGET ONLY


    #get SA4
    if region == 'SA3':
        SA3_shapefile_path = r"N:\Natural Perils\Data\Geographic\ABS\SA3\SA3_2021_AUST_GDA2020.shp"
        table = gpd.read_file(SA3_shapefile_path)
        table = table[['SA3_CODE21', 'SA4_CODE21', 'SA4_NAME21']]
        table = table.rename(columns={'SA3_CODE21': 'SA3','SA4_CODE21': 'SA4', 'SA4_NAME21': 'SA4_NAME'})
        gdf_overall['SA3'] = gdf_overall['SA3'].astype(str)
        gdf_overall = gdf_overall.merge(table, on='SA3', how='left')


    #######

    gdf_action_aptp = gdf_action_aptp[gdf_action_aptp['AP'] >= Target_AP_Threshold]
    gdf_action_aptp = gdf_action_aptp[[region, 'AP', 'AP_LABEL','Max_Peril_List']]
    gdf_action_aptp = gdf_action_aptp.rename(columns={'AP': 'Target_AP', 'AP_LABEL': 'Target_AP_LABEL','Max_Peril_List':'Target_Max_Peril_List'})
    gdf_overall = gdf_overall.merge(gdf_action_aptp, on=region, how='left')

    gdf_take_up = gdf_take_up[[region, 'TAKE_UP', 'TOTAL_COUNT']]
    gdf_overall = gdf_overall.merge(gdf_take_up, on=region, how='left')
    gdf_overall['Target_AP'] = gdf_overall['Target_AP'].fillna(0)

    gdf_action_acc = gdf_action_acc[gdf_action_acc['EL_EQ'] >= Acc_EQ_Threshold]
    gdf_action_acc = gdf_action_acc[['SA4', 'AP', 'EL_EQ']]
    gdf_action_acc = gdf_action_acc.rename(columns={'AP': 'Acc_AP', 'EL_EQ': 'Acc_EL_EQ'})
    gdf_overall = gdf_overall.merge(gdf_action_acc, on='SA4', how='left')
    gdf_overall['Acc_EL_EQ'] = gdf_overall['Acc_EL_EQ'].fillna(0)

    gdf_overall['CASE'] =2

    gdf_overall['CASE'] = np.where(((gdf_overall['Target_AP']<=Target_AP_Threshold) & (gdf_overall['AP/TP'] >= Case_APTP_Condition) & (gdf_overall['Acc_EL_EQ'] < Acc_EQ_Threshold)), 3, gdf_overall['CASE'])
    gdf_overall['CASE'] = np.where(((gdf_overall['Target_AP'] >= Target_AP_Threshold) | (gdf_overall['Acc_EL_EQ'] > Acc_EQ_Threshold)), 2, gdf_overall['CASE'])
    gdf_overall['CASE'] = np.where((gdf_overall['AP/TP'] < Case_APTP_Condition) & (gdf_overall['TAKE_UP'] > Take_Up_condition), 1, gdf_overall['CASE'])

    #CHECK: case 0 is when APTP is weak but it is not becasue of Natural Perils/Accumulation
        # #print all rows with CASE 0
        # gdf_overall[gdf_overall['CASE'] == 0]
        # #drop the CASE 0
        # gdf_overall = gdf_overall[gdf_overall['CASE'] != 0]

    gdf_overall['CASE'].hist()

    #Choropeth where SA3 is green if Case = 1, yellow if Case = 2, red if Case = 3
    Case = folium.Choropleth(
        geo_data=gdf_overall,
        data=gdf_overall,
        columns=[region, 'CASE'],
        key_on=f'feature.properties.{region}',
        fill_color='RdYlGn',  
        fill_opacity=0.8,
        line_opacity=0.2,
        legend_name=None, #'Case by region',
        name='Summary',
        show=True
    )
    Case.layer_name = 'Summary (Green:GROW / Yellow:ACTION / Red:RESTRICT)'

  

    #where CASE =1 then CASE_label = "GROW", CASE=2 then CASE_label = "ACTION PERIL", CASE=3 then CASE_label = "DO NOT GROW"
    gdf_overall['CASE_label'] = np.where(gdf_overall['CASE'] == 3, 'GROW', 'ACTION AND GROW')
    gdf_overall['CASE_label'] = np.where(gdf_overall['CASE'] == 2, 'ACTION AND GROW', gdf_overall['CASE_label'])
    gdf_overall['CASE_label'] = np.where(gdf_overall['CASE'] == 1, 'RESTRICT', gdf_overall['CASE_label'])

    #if CASE =3 then Target_AP = "-" and Max_Peril_List = "-"
    gdf_overall['Target_AP'] = np.where(gdf_overall['CASE'] == 3, '-', gdf_overall['Target_AP'])
    gdf_overall['Target_AP_LABEL'] = np.where(gdf_overall['CASE'] == 3, '-', gdf_overall['Target_AP_LABEL'])
    gdf_overall['Target_Max_Peril_List'] = np.where(gdf_overall['CASE'] == 3, '-', gdf_overall['Target_Max_Peril_List'])


    #drop rows with Max_Peril_List = "-"
    test_peril = gdf_overall[gdf_overall['Target_Max_Peril_List'] != '-']

    #table of number of times each peril appears in Max_Peril_List
    print(test_peril['Target_Max_Peril_List'].str.split(',').apply(pd.Series).stack().value_counts())

    # Print list of SA3s with EQ in its Max_Peril_List
    print("Regions with EQ in Max_Peril_List:")
    print(test_peril[test_peril['Target_Max_Peril_List'].fillna('').str.contains('EQ')])

    # Add "EQ Accumulation" to Target_Max_Peril_List if Acc_EL_EQ > Acc_EQ_Threshold
    gdf_overall['Target_Max_Peril_List'] = gdf_overall.apply(
        lambda row: str(row['Target_Max_Peril_List']) + ', EQ Accumulation' if row['Acc_EL_EQ'] > Acc_EQ_Threshold else str(row['Target_Max_Peril_List']),
        axis=1
    )

    gdf_overall['AP_LABEL'] = gdf_overall['AP'].map(lambda x: f"${x/1e6:1.1f}M")
    gdf_overall['BLANK'] = ' '


    folium.GeoJson(
        gdf_overall,  # this has to be a geodataframe with the geometry
        name=region,
        style_function=lambda _: {
            'fillColor': '#ffffff',
            'color': '#000000',
            'weight': 0.5,
            'fillOpacity': 0,
        },
        highlight_function=lambda _: {'weight': 3, 'color': 'blue'},
        tooltip=folium.GeoJsonTooltip(
            fields=[rf'{region}_NAME', 'CASE_label', 'BLANK','BLANK','BLANK','BLANK', 'Pricing Strength (AP/TP)', 'Cat Exposure', 'Accumulation', 'BLANK', 'BLANK', 'AP_LABEL', 'BLANK', 'BLANK', 'Target_AP_LABEL', 'Target_Max_Peril_List', 'BLANK', 'BLANK', 'BLANK', 'TAKE_UP', 'TOTAL_COUNT'],
            aliases=['Region Name:', 'ACTION:', ' ',' ',' ',' ', 'Overall Pricing Strength (AP/TP):', 'Overall Cat Exposure (CAT/AP):', 'Overall Accumulation (RE/AP):', ' ',' ', 'Total AP:', ' ', ' ', 'Action AP:', 'Action Segments:',' ',' ',' ','Take Up:', '','','','Industry Count:'],
            localize=True,
            sticky=True,
            labels=True,
            style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
        )
    ).add_to(Case)

    return Case, gdf_overall




def summary_layer_region(gdf_overall, gdf_action_aptp, gdf_action_acc, gdf_take_up, Case_APTP_Condition, Case_AP_Condition, Case_Acc_EQ_Condition, Case_Take_Up_Condition, region, Red_condition, hotspots_df ):
    
    ### NEED gpd_overall (gdf_overall) AND target (aptp filter, target_inf ) merged onto that
    ### SUMMARISE JUST THE TARGET ONLY
    if f'{region}_name' not in gdf_overall.columns:
        gdf_overall[rf'{region}_name'] = gdf_overall[region]

    if "S2" in region:
        gdf_overall[rf'{region}_NAME'] = "-"

    #get SA4
    if region == 'SA3':
        SA3_shapefile_path = r"N:\Natural Perils\Data\Geographic\ABS\SA3\SA3_2021_AUST_GDA2020.shp"
        table = gpd.read_file(SA3_shapefile_path)
        table = table[['SA3_CODE21', 'SA4_CODE21', 'SA4_NAME21']]
        table = table.rename(columns={'SA3_CODE21': 'SA3','SA4_CODE21': 'SA4', 'SA4_NAME21': 'SA4_NAME'})
        gdf_overall['SA3'] = gdf_overall['SA3'].astype(str)
        gdf_overall = gdf_overall.merge(table, on='SA3', how='left')


    #######

    #merge on action aptp 
    # gdf_action_aptp = gdf_action_aptp[gdf_action_aptp['AP'] >= Case_AP_Condition]
    gdf_action_aptp = gdf_action_aptp[[region, 'AP', 'AP_LABEL','Max_Peril_List']]
    gdf_action_aptp = gdf_action_aptp.rename(columns={'AP': 'Action_APTP_AP', 'Max_Peril_List':'Target_Max_Peril_List'})
    gdf_overall = gdf_overall.merge(gdf_action_aptp, on=region, how='left')
    gdf_overall['Action_APTP_AP'] = gdf_overall['Action_APTP_AP'].fillna(0)
    gdf_overall['Action_APTP_AP'] = np.where(gdf_overall['Action_APTP_AP'] < Case_AP_Condition, 0, gdf_overall['Action_APTP_AP'])

    #merge on take-up
    gdf_take_up = gdf_take_up[[region, 'TAKE_UP', 'TOTAL_COUNT']]
    gdf_overall = gdf_overall.merge(gdf_take_up, on=region, how='left')

    #merge on hotspots
    hotspots_SA3 = hotspots_df.groupby(region).agg(
        SI_Sum=('SI', 'sum')
    ).reset_index()
    hotspots_SA3 = hotspots_SA3.rename(columns={'SI_Sum': 'HOTSPOT_SI'})
    hotspots_SA3[region] = hotspots_SA3[region].astype(str)
    gdf_overall = gdf_overall.merge(hotspots_SA3, on=region, how='left')

    #merge on action accumulation
    gdf_action_acc = gdf_action_acc[gdf_action_acc['EL_EQ'] >= Case_Acc_EQ_Condition]
    gdf_action_acc = gdf_action_acc[[region, 'AP', 'EL_EQ']]
    gdf_action_acc = gdf_action_acc.rename(columns={'AP': 'Action_Acc_AP', 'EL_EQ': 'Acc_EL_EQ'})
    gdf_overall = gdf_overall.merge(gdf_action_acc, on=region, how='left')
    gdf_overall['Action_Acc_AP'] = gdf_overall['Action_Acc_AP'].fillna(0)
    gdf_overall['Acc_EL_EQ'] = gdf_overall['Acc_EL_EQ'].fillna(0)
    gdf_overall['Action_Acc_AP'] = np.where(gdf_overall['Action_Acc_AP'] < Case_AP_Condition, 0, gdf_overall['Action_Acc_AP'])



    #combine action aptp and action accumulation
    gdf_overall['Target_AP'] = gdf_overall['Action_APTP_AP'] + gdf_overall['Action_Acc_AP']
    gdf_overall['Target_AP_LABEL'] = gdf_overall['Target_AP'].map(lambda x: f"${x/1e6:1.1f}M")

    
    gdf_overall['Target_perc_total_AP'] =  gdf_overall['Target_AP']/ gdf_overall['AP']
    gdf_overall['Target_perc_action_AP'] =  gdf_overall['Action_APTP_AP']/ gdf_overall['AP']



    gdf_overall['CASE'] =2

    gdf_overall['CASE'] = np.where(((gdf_overall['Target_AP'] <Case_AP_Condition) & (gdf_overall['AP/TP'] >= Case_APTP_Condition) & (gdf_overall['Acc_EL_EQ'] < Case_Acc_EQ_Condition)), 3, gdf_overall['CASE'])
    gdf_overall['CASE'] = np.where(((gdf_overall['Target_AP'] >= Case_AP_Condition) | (gdf_overall['Acc_EL_EQ'] > Case_Acc_EQ_Condition)), 2, gdf_overall['CASE'])
    if Red_condition == 'perc':
        gdf_overall['CASE'] = np.where((gdf_overall['Target_perc_total_AP']>0.4) |  (gdf_overall['Target_AP'] >= Case_AP_Condition) & (gdf_overall['HOTSPOT_SI'] > 100) , 1, gdf_overall['CASE'])
    else:
        # gdf_overall['CASE'] = np.where((gdf_overall['AP/TP'] < Case_APTP_Condition) & (gdf_overall['TAKE_UP'] > Case_Take_Up_Condition), 1, gdf_overall['CASE'])
        # gdf_overall['CASE'] = np.where((gdf_overall['AP/TP'] < Case_APTP_Condition) & (gdf_overall['HOTSPOT_SI'] > 100), 1, gdf_overall['CASE'])
        gdf_overall['CASE'] = np.where((gdf_overall['Target_AP'] >= Case_AP_Condition) & (gdf_overall['HOTSPOT_SI'] > 100), 1, gdf_overall['CASE'])


    #CHECK: case 0 is when APTP is weak but it is not becasue of Natural Perils/Accumulation
        # #print all rows with CASE 0
        # gdf_overall[gdf_overall['CASE'] == 0]
        # #drop the CASE 0
        # gdf_overall = gdf_overall[gdf_overall['CASE'] != 0]

    gdf_overall['CASE'].hist()

    #Choropeth where SA3 is green if Case = 1, yellow if Case = 2, red if Case = 3
    Case = folium.Choropleth(
        geo_data=gdf_overall,
        data=gdf_overall,
        columns=[region, 'CASE'],
        key_on=f'feature.properties.{region}',
        fill_color='RdYlGn',  
        fill_opacity=0.8,
        line_opacity=0.2,
        legend_name=None, #'Case by region',
        name='Summary',
        show=True
    )
    Case.layer_name = 'Summary (Green:Grow / Yellow:Action / Red:Restrict)'

  

    #where CASE =1 then CASE_label = "GROW", CASE=2 then CASE_label = "ACTION PERIL", CASE=3 then CASE_label = "DO NOT GROW"
    gdf_overall['CASE_label'] = np.where(gdf_overall['CASE'] == 3, 'GROW', 'ACTION AND GROW')
    gdf_overall['CASE_label'] = np.where(gdf_overall['CASE'] == 2, 'ACTION AND GROW', gdf_overall['CASE_label'])
    gdf_overall['CASE_label'] = np.where(gdf_overall['CASE'] == 1, 'RESTRICT', gdf_overall['CASE_label'])

    gdf_overall['CASE_detail_1'] = np.where(gdf_overall['CASE'] == 3, 'NatCat Risk and Accumulation is profitable', 'Increase prices for specific perils and regions, and grow the rest')
    gdf_overall['CASE_detail_2'] = np.where(gdf_overall['CASE'] == 3, '', 'Increase prices for specific perils and regions, and grow the rest')
    
    gdf_overall['CASE_detail_1'] = np.where(gdf_overall['CASE'] == 2, 'Increase prices for specific perils and regions,', gdf_overall['CASE_detail_1'])
    gdf_overall['CASE_detail_2'] = np.where(gdf_overall['CASE'] == 2, 'Grow the rest', gdf_overall['CASE_detail_2'])


    if Red_condition == 'perc':
        gdf_overall['CASE_detail_1'] = np.where((gdf_overall['Target_perc_total_AP']>0.3) & (gdf_overall['HOTSPOT_SI'] > 100), 'Reduce exposure in market share hotspots,', gdf_overall['CASE_detail_1'])
        gdf_overall['CASE_detail_2'] = np.where((gdf_overall['Target_perc_total_AP']>0.3) & (gdf_overall['HOTSPOT_SI'] > 100), 'Increase prices for specific perils and regions', gdf_overall['CASE_detail_2'])
        
        gdf_overall['CASE_detail_1'] = np.where(gdf_overall['Target_perc_total_AP']>0.5, 'Majority of region is underpriced:', gdf_overall['CASE_detail_1'])
        gdf_overall['CASE_detail_2'] = np.where(gdf_overall['Target_perc_total_AP']>0.5, 'Do not grow and major actions needed', gdf_overall['CASE_detail_2'])
    
    else:
        gdf_overall['CASE_detail_1'] = np.where(gdf_overall['CASE'] == 1, 'Reduce exposure in market share hotspots,', gdf_overall['CASE_detail_1'])
        gdf_overall['CASE_detail_2'] = np.where(gdf_overall['CASE'] == 1, 'Increase prices for specific perils and regions', gdf_overall['CASE_detail_2'])
    

    #if CASE =3 then Target_AP = "-" and Max_Peril_List = "-"
    gdf_overall['Target_AP'] = np.where(gdf_overall['CASE'] == 3, '-', gdf_overall['Target_AP'])
    gdf_overall['Target_AP_LABEL'] = np.where(gdf_overall['CASE'] == 3, '-', gdf_overall['Target_AP_LABEL'])
    gdf_overall['Target_Max_Peril_List'] = np.where(gdf_overall['CASE'] == 3, '-', gdf_overall['Target_Max_Peril_List'])


    #drop rows with Max_Peril_List = "-"
    test_peril = gdf_overall[gdf_overall['Target_Max_Peril_List'] != '-']

    #table of number of times each peril appears in Max_Peril_List
    print(test_peril['Target_Max_Peril_List'].str.split(',').apply(pd.Series).stack().value_counts())

    # Print list of SA3s with EQ in its Max_Peril_List
    print("Regions with EQ in Max_Peril_List:")
    print(test_peril[test_peril['Target_Max_Peril_List'].fillna('').str.contains('EQ')])

    # Add "EQ Accumulation" to Target_Max_Peril_List if Acc_EL_EQ > Case_Acc_EQ_Condition
    gdf_overall['Target_Max_Peril_List'] = gdf_overall.apply(
        lambda row: 'EQ Accumulation' if row['Acc_EL_EQ'] > Case_Acc_EQ_Condition and not row['Target_Max_Peril_List'] else str(row['Target_Max_Peril_List']) + ', EQ Accumulation' if row['Acc_EL_EQ'] > Case_Acc_EQ_Condition else str(row['Target_Max_Peril_List']),
        axis=1
    )

    gdf_overall['TAKE_UP_LABEL'] = gdf_overall['TAKE_UP'].map(lambda x: f"{x*100:.1f}%")
    gdf_overall['AP_LABEL'] = gdf_overall['AP'].map(lambda x: f"${x/1e6:1.1f}M")
    gdf_overall['BLANK'] = ' '

    

    folium.GeoJson(
        gdf_overall,  # this has to be a geodataframe with the geometry
        name=region,
        style_function=lambda _: {
            'fillColor': '#ffffff',
            'color': '#000000',
            'weight': 0.5,
            'fillOpacity': 0,
        },
        highlight_function=lambda _: {'weight': 3, 'color': 'blue'},
        tooltip=folium.GeoJsonTooltip(
            fields=[rf'{region}_NAME', 'CASE_label', 'CASE_detail_1','CASE_detail_2', 'BLANK','BLANK','BLANK','BLANK', 'Pricing Strength (AP/TP)', 'Cat Exposure', 'Accumulation', 'BLANK', 'BLANK', 'AP_LABEL', 'BLANK', 'BLANK', 'Target_AP_LABEL', 'Target_Max_Peril_List', 'BLANK', 'BLANK', 'BLANK', 'TAKE_UP_LABEL', 'TOTAL_COUNT'],
            aliases=['Region Name:', 'ACTION:','', '', ' ',' ',' ',' ', 'Overall Pricing Strength (AP/TP):', 'Overall Cat Exposure (CAT/AP):', 'Accumulation (RE/AP):', ' ',' ', 'Total AP:', ' ', ' ', 'Action AP:', 'Action Segments:',' ',' ',' ','Allianz Take Up:','Total Industry Count:'],
            localize=True,
            sticky=True,
            labels=True,
            style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
        )
    ).add_to(Case)

    return Case, gdf_overall




#Action_accumulation_layer(LOB, region='SA4', region_name='SA4_NAME', gdf_region=gdf_SA4, action_accumulation_regions, action_accumulation_locations, EQ_threshold=16e3)  # 305 is manually remoced
def Action_accumulation_layer(LOB, region, region_name, gdf_region, action_accumulation_regions, action_accumulation_locations, EQ_threshold):

    if LOB != 'ISR':

        # ----------Unprofitable Accumulation-----------------
        
        df_acc = pd.read_csv(action_accumulation_regions)

        #get SA4
        SA3_shapefile_path = r"N:\Natural Perils\Data\Geographic\ABS\SA3\SA3_2021_AUST_GDA2020.shp"
        table = gpd.read_file(SA3_shapefile_path)
        table = table[['SA3_CODE21', 'SA4_CODE21','SA4_NAME21']]
        table = table.rename(columns={'SA3_CODE21': 'SA3','SA4_CODE21': 'SA4', 'SA4_NAME21': 'SA4_NAME'})
        df_acc['SA3'] = df_acc['SA3'].astype(str)
        df_acc = df_acc.merge(table, on='SA3', how='left')

        df_summary = df_acc.groupby([region, 'LOB_detail1']).agg({
            'AP': 'sum',
            'EL_EQ': 'sum'
        }).reset_index()

        df_summary = df_summary[df_summary['LOB_detail1'].str.upper() == LOB.upper()]

        # df_summary['AP'] = df_summary['AP'].map(lambda x: f"${x/1e6:1.1f}M")
        # df_summary['EL_EQ'] = df_summary['EL_EQ'].map(lambda x: f"${x/1e6:1.1f}M")
        df_summary = df_summary[df_summary['EL_EQ'] > EQ_threshold]

        
        gdf_region = eval(rf'gdf_{region}')

        df_summary[region] = df_summary[region].astype(str)
        gdf_region[region] = gdf_region[region].astype(str)
        gdf = gdf_region.merge(df_summary, left_on=region, right_on=region, how='left')

        gdf = gdf.dropna(subset=['EL_EQ'])

        #drop SA4 305 and 904
        if 'SA4' in gdf.columns:
            gdf = gdf[gdf['SA4'] != '305']

        gdf['AP_LABEL'] = gdf['AP'].map(lambda x: f"${x/1e6:1.1f}M")
        gdf['EL_EQ_LABEL'] = gdf['EL_EQ'].map(lambda x: f"${x/1e3:1.1f}K")
        gdf['BLANK'] = ' '

        unprofitable_accumulation = folium.Choropleth(
            geo_data=gdf,
            data=gdf,
            columns=[region, 'EL_EQ'],
            key_on=rf'feature.properties.{region}',
            fill_color='Reds',
            fill_opacity=0.7,
            line_opacity=0.2,
            legend_name=None, #'Unprofitable Accumulation',
            nan_fill_color='transparent',
            show=False  
        )
        unprofitable_accumulation.layer_name = 'Action Segment: unprofitable accumulation (shading: EQ AAL)'

        # df['EQ_AAL'] = df['EQ_AAL'].map(lambda x: f"${x/1e6:1.1f}M")
        # df['AP'] = df['AP'].map(lambda x: f"${x/1e6:1.1f}M")
        # df['Count'] = df['Count'].map(lambda x: f"{x:1.1f}K")

        # print("Total AP in Action Segment Unprofitable Accumulation: ", df['AP'].sum())

        folium.GeoJson(
            gdf,
            name='Unprofitable Accumulation',
            style_function=lambda feature: {
                'fillColor': '#ffffff',
                'color': '#000000',
                'weight': 0.5,
                'fillOpacity': 0,
            },
            highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
            tooltip=folium.GeoJsonTooltip(
                fields=['BLANK', 'BLANK', 'BLANK','BLANK', region, rf'{region}_NAME', 'EL_EQ_LABEL', 'AP_LABEL'],
                aliases=['Action Segment: Excess Accumulation','Target oldest unreinforced masonry',' ',' ', 'Region:', 'Region Name:', 'Excess EQ AAL:', 'Matching AP:'],
                localize=True,
                sticky=True,
                labels=True,
                style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;"),
            )
        ).add_to(unprofitable_accumulation)

    else:
            
        #adding in top policies ISR
            
        # read in "N:\Natural Perils\Data\Exposures\ASPIRE\202407\risk_level_ISR_EQ.csv"
        risk_level_ISR_EQ = action_accumulation_locations

        #print sum of AP
        print(risk_level_ISR_EQ['AP'].sum())
        #print sum of TP
        print(risk_level_ISR_EQ['TP'].sum())
        print(risk_level_ISR_EQ['AP'].sum()/risk_level_ISR_EQ['TP'].sum())




        #pd.read_csv(r"N:\Natural Perils\Data\Exposures\ASPIRE\202407\risk_level_ISR_EQ.csv")
        #list all columns
        risk_level_ISR_EQ.columns
        #M_RP_WT = M_RP_ST + M_RP_HL + M_RP_CY
        risk_level_ISR_EQ['M_RP_WT'] = risk_level_ISR_EQ['M_RP_ST'] + risk_level_ISR_EQ['M_RP_HL'] + risk_level_ISR_EQ['M_RP_CY']

        #keep latitude and longitude
        risk_level_ISR_EQ = risk_level_ISR_EQ[['LATITUDE', 'LONGITUDE','SI','AP/TP','POLICY','AP','TP','RP','M_RP', 'M_RP_EQ', 'M_RP_FL','M_RP_BF', 'M_RP_WT','LIMIT_POLICY']]


        #summarise by POLICY
        Policy_sum = risk_level_ISR_EQ.groupby(['POLICY']).agg({
            'SI': 'sum',
            'AP': 'sum', 
            'TP': 'sum',
            'RP': 'sum',
            'M_RP': 'sum',
            'LATITUDE': 'count',
            'M_RP_EQ': 'sum',
            'M_RP_FL': 'sum',
            'M_RP_BF': 'sum',
            'M_RP_WT': 'sum',
            'LIMIT_POLICY': 'first'
        }).reset_index()

        #rename LATITUDE as COUNT
        Policy_sum = Policy_sum.rename(columns={'LATITUDE': 'COUNT'})

        #sort by COUNT descending
        Policy_sum = Policy_sum.sort_values(by='COUNT', ascending=False)

        #print sum of AP
        print(Policy_sum['AP'].sum())
        #print sum of TP
        print(Policy_sum['TP'].sum())
        print(Policy_sum['AP'].sum()/Policy_sum['TP'].sum())

        #calculate AP/TP
        Policy_sum['POLICY_AP/TP'] = Policy_sum['AP'] / Policy_sum['TP']
        #rename SI as POLICY_SI, AP as POLICY_AP, TP as POLICY_TP, COUNT as POLICY_COUNT
        Policy_sum = Policy_sum.rename(columns={'SI': 'POLICY_SI', 'AP': 'POLICY_AP', 'TP': 'POLICY_TP', 'COUNT': 'POLICY_COUNT','RP': 'POLICY_RP','M_RP': 'POLICY_M_RP', 'M_RP_EQ': 'POLICY_M_RP_EQ','M_RP_FL': 'POLICY_M_RP_FL','M_RP_BF': 'POLICY_M_RP_BF', 'M_RP_WT': 'POLICY_M_RP_WT'})

        #sort by POLICY_M_RP descending
        Policy_sum = Policy_sum.sort_values(by='POLICY_M_RP', ascending=False)


        Policy_sum_target = Policy_sum[Policy_sum['POLICY_M_RP'] > Policy_sum['POLICY_AP']]




        Policy_sum['Main Location'] =""

        #for each policy, find the CRESTA that has the highest total SI
        for policy in Policy_sum['POLICY']:
            policy_data = isr_risks[isr_risks['POLICY'] == policy]
            highest_cresta = policy_data.groupby('CRESTA')['SI'].sum().idxmax()
            Policy_sum.loc[Policy_sum['POLICY'] == policy, 'Main Location'] = highest_cresta

        #read in 'all_postcodes' sheet in "N:\Natural Perils\Data\Geographic\CRESTA\RMS Postcode to CRESTA mapping 2017 v2.xlsx"
        all_postcodes = pd.read_excel(r"N:\Natural Perils\Data\Geographic\CRESTA\RMS Postcode to CRESTA mapping 2017 v2.xlsx", sheet_name='all_postcodes')
        # keep unique CRESTA and CRESTA_name
        all_postcodes = all_postcodes[['CRESTA', 'CRESTA_NAME']]
        #drop duplicates
        all_postcodes = all_postcodes.drop_duplicates()

        #create "CRESTA Name" in Policy_sum by looking up CRESTA in all_postcodes
        Policy_sum = Policy_sum.merge(all_postcodes, left_on='Main Location', right_on='CRESTA', how='inner')



        #export to csv
        Policy_sum.to_csv(rf"N:\Natural Perils\Exposure Management\Monitoring_py\{mth}\Python\Top Marginal RI Policies.csv")

        #merge Policy_sum on risk_level_ISR_EQ by POLICY
        risk_level_ISR_EQ = risk_level_ISR_EQ.merge(Policy_sum_target, left_on='POLICY', right_on='POLICY', how='inner')
        # drop rows with missing POLICY_SI
        risk_level_ISR_EQ = risk_level_ISR_EQ.dropna(subset=['POLICY_SI'])


        print("Total AP in Action Segment ISR: ", risk_level_ISR_EQ['AP'].sum())

        # Add tooltips to the circles
        unprofitable_accumulation = folium.FeatureGroup(name='Action Segment: Unprofitable Accumulation', show=False)
        for i in range(0, len(risk_level_ISR_EQ)):
            folium.Circle(
            location=[risk_level_ISR_EQ.iloc[i]['LATITUDE'], risk_level_ISR_EQ.iloc[i]['LONGITUDE']],
            radius=400,
            color='red',
            fill=True,
            fill_color='red',
            tooltip=folium.Tooltip(
                f"Policy: {risk_level_ISR_EQ.iloc[i]['POLICY']}<br>"
                f"Policy AP/TP: {risk_level_ISR_EQ.iloc[i]['POLICY_AP/TP']:.2f}<br>"
                f"Policy SI: ${risk_level_ISR_EQ.iloc[i]['POLICY_SI'] / 1e6:.1f}M<br>"
                f"Policy AP: ${risk_level_ISR_EQ.iloc[i]['POLICY_AP'] / 1e3:.1f}K<br>"
                f"Count: {risk_level_ISR_EQ.iloc[i]['POLICY_COUNT'] :.0f}<br>"
                f"RI Premium: ${risk_level_ISR_EQ.iloc[i]['POLICY_RP'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium EQ: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_EQ'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium FL: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_FL'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium BF: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_BF'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium WT: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_WT'] / 1e3:.1f}K",
                style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
            )
            ).add_to(unprofitable_accumulation)
        # unprofitable_accumulation.add_to(base_map)



    # -----------------------------------

    # unfunded_volatility = folium.FeatureGroup(name='Unfunded Volatility (pending)',show=False)
    # unfunded_volatility.add_to(base_map)


    # ------------------------------------------
    return unprofitable_accumulation, gdf



# (LOB, region=region_select, region_name, gdf_region=region_select_gdf, action_accumulation_regions, action_accumulation_locations, EQ_threshold=10e3)  # 305 is manually remoced

def Action_accumulation_layer_region(LOB, region, action_accumulation_regions, action_accumulation_locations, Layer_Acc_EQ_Threshold):

    # ----------Unprofitable Accumulation-----------------
    
    df_acc = pd.read_csv(action_accumulation_regions)
    df_acc['S2_TK_10'] = df_acc['S2_TK_12'].apply(lambda x: get_parent_cell_token_level_X(x, s2_level=10))
    df_acc['S2_ID_10'] = df_acc['S2_TK_10'].apply(get_cell_id_from_token)
    df_acc['S2_TK_9'] = df_acc['S2_TK_12'].apply(lambda x: get_parent_cell_token_level_X(x, s2_level=9))
    df_acc['S2_ID_9'] = df_acc['S2_TK_9'].apply(get_cell_id_from_token)
    df_acc['S2_TK_8'] = df_acc['S2_TK_12'].apply(lambda x: get_parent_cell_token_level_X(x, s2_level=8))
    df_acc['S2_ID_8'] = df_acc['S2_TK_8'].apply(get_cell_id_from_token)
    df_acc['S2_ID'] = df_acc[region]
    if rf'{region}_NAME' not in df.columns:
        df_acc[rf'{region}_NAME'] = "-"


    # #get SA4
    # SA3_shapefile_path = r"N:\Natural Perils\Data\Geographic\ABS\SA3\SA3_2021_AUST_GDA2020.shp"
    # table = gpd.read_file(SA3_shapefile_path)
    # table = table[['SA3_CODE21', 'SA4_CODE21','SA4_NAME21']]
    # table = table.rename(columns={'SA3_CODE21': 'SA3','SA4_CODE21': 'SA4', 'SA4_NAME21': 'SA4_NAME'})
    # df_acc['SA3'] = df_acc['SA3'].astype(str)
    # df_acc = df_acc.merge(table, on='SA3', how='left')

    df_summary = df_acc.groupby([region, rf'{region}_NAME', 'LOB_detail1']).agg({
        'AP': 'sum',
        'EL_EQ': 'sum'
    }).reset_index()

    df_summary = df_summary[df_summary['LOB_detail1'].str.upper() == LOB.upper()]

    df_summary[region] = df_summary[region].astype(str)

    gdf_region = eval(rf'gdf_{region}')

    gdf_region[region] = gdf_region[region].astype(str)
    gdf = gdf_region.merge(df_summary, left_on=region, right_on=region, how='left')

    gdf_all = gdf

    gdf = gdf.dropna(subset=['EL_EQ'])
    gdf = gdf[gdf['EL_EQ'] > Layer_Acc_EQ_Threshold]


    # #drop SA4 305 and 904
    # if 'SA4' in gdf.columns:
    #     gdf = gdf[gdf['SA4'] != '305']

    gdf['AP_LABEL'] = gdf['AP'].map(lambda x: f"${x/1e6:1.1f}M")
    gdf['EL_EQ_LABEL'] = gdf['EL_EQ'].map(lambda x: f"${x/1e3:1.1f}K")
    gdf['BLANK'] = ' '



    unprofitable_accumulation = folium.Choropleth(
        geo_data=gdf,
        data=gdf,
        columns=[region, 'EL_EQ'],
        key_on=rf'feature.properties.{region}',
        fill_color='Reds',
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name=None, #'Unprofitable Accumulation',
        nan_fill_color='transparent',
        show=False  
    )
    unprofitable_accumulation.layer_name = 'Action Segment: Unprofitable Accumulation (shading: EQ AAL)'

    # df['EQ_AAL'] = df['EQ_AAL'].map(lambda x: f"${x/1e6:1.1f}M")
    # df['AP'] = df['AP'].map(lambda x: f"${x/1e6:1.1f}M")
    # df['Count'] = df['Count'].map(lambda x: f"{x:1.1f}K")

    # print("Total AP in Action Segment Unprofitable Accumulation: ", df['AP'].sum())

    folium.GeoJson(
        gdf,
        name='Unprofitable Accumulation',
        style_function=lambda feature: {
            'fillColor': '#ffffff',
            'color': '#000000',
            'weight': 0.5,
            'fillOpacity': 0,
        },
        highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
        tooltip=folium.GeoJsonTooltip(
            fields=['BLANK', 'BLANK', 'BLANK','BLANK', region, rf'{region}_NAME', 'EL_EQ_LABEL', 'AP_LABEL'],
            aliases=['Action Segment: Excess Accumulation','Target oldest unreinforced masonry',' ',' ', 'Region:', 'Region Name:', 'Excess EQ AAL:', 'Matching AP:'],
            localize=True,
            sticky=True,
            labels=True,
            style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;"),
        )
    ).add_to(unprofitable_accumulation)

    
    return unprofitable_accumulation, gdf_all






#temporary - to be added to summarise_by_region with parameter region=S2
#def summarise_by_region_S2(df, region, region_gdf, aptp_min, aptp_max):

def create_inforce_s2(df, s2_select, shading_cap_percentile):
    
    ## in df keep all EL_* columns and TSI
    if f'S2_TK_{s2_select}' not in df.columns:
        raise KeyError(f"Column 'S2_TK_{s2_select}' does not exist in the DataFrame")
    df['S2_TK'] = df[f'S2_TK_{s2_select}']
    
    # , 'EL_EQ']
    # , 'EL_CY', 'EL_BF', 'EL_HL', 'EL_ST', 'EL_FL', 'SI', 'RE', 'EL']
 
    
    # Summarize sum of EL_EQ, EL_CY, EL_BF, EL_HL, EL_ST, EL_FL, TSI by S2_TK
    summ = df.groupby('S2_TK').agg({
        'EL_EQ': 'sum',
        'EL_CY': 'sum',
        'EL_BF': 'sum',
        'EL_HL': 'sum',
        'EL_ST': 'sum',
        'EL_FL': 'sum',
        'SI': 'sum',
        'EL': 'sum',
        'RE': 'sum',
        'AP' : 'sum',
        'TP' : 'sum',
        'RE_EQ': 'sum',
        'RE_CY': 'sum',
        'RE_BF': 'sum',
        'RE_HL': 'sum',
        'RE_ST': 'sum',
        'RE_FL': 'sum',
        }).reset_index()
    #cap values to the top shading_cap_percentile%
    summ['SI'] = summ['SI'].clip(upper=summ['SI'].quantile(shading_cap_percentile))
    summ['RE'] = summ['RE'].clip(upper=summ['RE'].quantile(shading_cap_percentile))
    summ['EL'] = summ['EL'].clip(upper=summ['EL'].quantile(shading_cap_percentile))
    #cap EL_* values to the top shading_cap_percentile%
    summ['EL_EQ'] = summ['EL_EQ'].clip(upper=summ['EL_EQ'].quantile(shading_cap_percentile))
    summ['EL_CY'] = summ['EL_CY'].clip(upper=summ['EL_CY'].quantile(shading_cap_percentile))
    summ['EL_BF'] = summ['EL_BF'].clip(upper=summ['EL_BF'].quantile(shading_cap_percentile))
    summ['EL_HL'] = summ['EL_HL'].clip(upper=summ['EL_HL'].quantile(shading_cap_percentile))
    summ['EL_ST'] = summ['EL_ST'].clip(upper=summ['EL_ST'].quantile(shading_cap_percentile))
    summ['EL_FL'] = summ['EL_FL'].clip(upper=summ['EL_FL'].quantile(shading_cap_percentile))


    gpkg_file_path = rf"N:\Natural Perils\Data\Geographic\S2 grids\S2_{s2_select}\S2_{s2_select}.gpkg"
    gdf = gpd.read_file(gpkg_file_path, epsg=7844)
    ######### gdf.set_crs(epsg=7844, inplace=True)  

    # Merge onto gdf
    gdf = gdf.merge(summ, left_on='S2_TK', right_on='S2_TK', how='left')
    
    # Drop missing HAZARD
    gdf = gdf.dropna(subset=['SI'])

    # # Max of hazard
    # print(gdf['HAZARD'].max())

    # #bin hazard into 10 categories as deciles
    # gdf['HAZARD'] = pd.qcut(gdf['HAZARD'], q=10, labels=False, duplicates='drop')

    # # Round(hazard*10)
    # #gdf['HAZARD'] = round(gdf['HAZARD']*10)

    # # Keep hazard, geometry 
    # gdf = gdf[['HAZARD', 'geometry']]

    #convert to geodataframe
    gdf = gpd.GeoDataFrame(gdf, geometry='geometry')

    #print crs
    print(gdf.crs)

    # output_path = rf"N:\Natural Perils\Accumulation\Monitoring_py\2409\Python\Peril S2 maps\S2_{s2_select}_{peril}.gpkg"
    # gdf.to_file(output_path, driver="GPKG")

    # # Dissolve by HAZARD
    # gdf = gdf.dissolve(by='HAZARD')

    return gdf


# create_inforce_s2
def create_inforce_region(df, region_select, shading_cap_percentile):
    
    if "S2_" in region_select:
        ## in df keep all EL_* columns and TSI
        if f'S2_TK_{s2_select}' not in df.columns:
            raise KeyError(f"Column 'S2_TK_{s2_select}' does not exist in the DataFrame")
        df['S2_TK'] = df[f'S2_TK_{s2_select}']

    
    # , 'EL_EQ']
    # , 'EL_CY', 'EL_BF', 'EL_HL', 'EL_ST', 'EL_FL', 'SI', 'RE', 'EL']
 
    
    # Summarize sum of EL_EQ, EL_CY, EL_BF, EL_HL, EL_ST, EL_FL, TSI by S2_TK
    summ = df.groupby(region_select).agg({
        'EL_EQ': 'sum',
        'EL_CY': 'sum',
        'EL_BF': 'sum',
        'EL_HL': 'sum',
        'EL_ST': 'sum',
        'EL_FL': 'sum',
        'SI': 'sum',
        'EL': 'sum',
        'RE': 'sum',
        'AP' : 'sum',
        'TP' : 'sum',
        'RE_EQ': 'sum',
        'RE_CY': 'sum',
        'RE_BF': 'sum',
        'RE_HL': 'sum',
        'RE_ST': 'sum',
        'RE_FL': 'sum',
        }).reset_index()
    #cap values to the top shading_cap_percentile%
    summ['SI_CAP'] = summ['SI'].clip(upper=summ['SI'].quantile(shading_cap_percentile))
    summ['RE_CAP'] = summ['RE'].clip(upper=summ['RE'].quantile(shading_cap_percentile))
    summ['EL_CAP'] = summ['EL'].clip(upper=summ['EL'].quantile(shading_cap_percentile))
    #cap EL_* values to the top shading_cap_percentile%
    summ['EL_EQ_CAP'] = summ['EL_EQ'].clip(upper=summ['EL_EQ'].quantile(shading_cap_percentile))
    summ['EL_CY_CAP'] = summ['EL_CY'].clip(upper=summ['EL_CY'].quantile(shading_cap_percentile))
    summ['EL_BF_CAP'] = summ['EL_BF'].clip(upper=summ['EL_BF'].quantile(shading_cap_percentile))
    summ['EL_HL_CAP'] = summ['EL_HL'].clip(upper=summ['EL_HL'].quantile(shading_cap_percentile))
    summ['EL_ST_CAP'] = summ['EL_ST'].clip(upper=summ['EL_ST'].quantile(shading_cap_percentile))
    summ['EL_FL_CAP'] = summ['EL_FL'].clip(upper=summ['EL_FL'].quantile(shading_cap_percentile))


    if "S2_" in region_select:
        gpkg_file_path = rf"N:\Natural Perils\Data\Geographic\S2 grids\S2_{s2_select}\S2_{s2_select}.gpkg"
        gdf = gpd.read_file(gpkg_file_path, epsg=7844)
        ######### gdf.set_crs(epsg=7844, inplace=True)  
    if "SA" in region_select:
        shapefile_path = rf"N:\Natural Perils\Data\Geographic\ABS\{region_select}\{region_select}_2021_AUST_GDA2020.shp"
        gdf = gpd.read_file(shapefile_path)[['SA3_CODE21', 'geometry']]
        gdf.rename(columns={'SA3_CODE21': 'SA3'}, inplace=True)
        gdf['SA3'] = gdf['SA3'].replace('ZZZZZ', '99999')
        gdf['geometry'] = gdf['geometry'].simplify(tolerance=0.01, preserve_topology=True)
        # #gdf_SA3['geometry'] = gdf_SA3['geometry'].buffer(0)
        gdf = gdf.dropna(subset=['geometry'])
        print(gdf.crs)
        gdf[region_select] = gdf[region_select].astype(int).astype(str)
        summ[region_select] = summ[region_select].replace('ZZZZZ', '99999')
        summ[region_select] = summ[region_select].astype(int).astype(str)


    # Merge onto gdf
    gdf = gdf.merge(summ, left_on=region_select, right_on=region_select, how='left')
    
    # Drop missing HAZARD
    gdf = gdf.dropna(subset=['SI'])

    # # Max of hazard
    # print(gdf['HAZARD'].max())

    # #bin hazard into 10 categories as deciles
    # gdf['HAZARD'] = pd.qcut(gdf['HAZARD'], q=10, labels=False, duplicates='drop')

    # # Round(hazard*10)
    # #gdf['HAZARD'] = round(gdf['HAZARD']*10)

    # # Keep hazard, geometry 
    # gdf = gdf[['HAZARD', 'geometry']]

    #convert to geodataframe
    gdf = gpd.GeoDataFrame(gdf, geometry='geometry')

    #print crs
    print(gdf.crs)

    # output_path = rf"N:\Natural Perils\Accumulation\Monitoring_py\2409\Python\Peril S2 maps\S2_{s2_select}_{peril}.gpkg"
    # gdf.to_file(output_path, driver="GPKG")

    # # Dissolve by HAZARD
    # gdf = gdf.dissolve(by='HAZARD')

    return gdf







############################################################################




def Action_accumulation_layer_CRESTA(LOB, action_accumulation_regions, action_accumulation_locations):

    if LOB != 'ISR':

        # ----------Unprofitable Accumulation-----------------
        CRESTA_MAP_file_path = "N:/Natural Perils/Data/Geographic/CRESTA/CRESTA_map_python.gpkg"
        gdf = gpd.read_file(CRESTA_MAP_file_path)

        df = pd.read_excel(action_accumulation_regions, sheet_name=LOB)

        gdf = gdf.merge(df, on='CRESTA')

        unprofitable_accumulation = folium.Choropleth(
            geo_data=gdf,
            data=gdf,
            columns=['CRESTA', 'EQ_AAL'],
            key_on='feature.properties.CRESTA',
            fill_color='YlOrRd',
            fill_opacity=0.7,
            line_opacity=0.2,
            legend_name=None, #'Unprofitable Accumulation',
            nan_fill_color='transparent',
            show=False  
        )
        unprofitable_accumulation.layer_name = 'Action Segment: Unprofitable Accumulation by CRESTA (shading: GWP)'

        df['EQ_AAL'] = df['EQ_AAL'].map(lambda x: f"${x/1e6:1.1f}M")
        df['AP'] = df['AP'].map(lambda x: f"${x/1e6:1.1f}M")
        df['Count'] = df['Count'].map(lambda x: f"{x:1.1f}K")

        print("Total AP in Action Segment Unprofitable Accumulation: ", df['AP'].sum())

        folium.GeoJson(
            gdf,
            name='Unprofitable Accumulation',
            style_function=lambda feature: {
                'fillColor': '#ffffff',
                'color': '#000000',
                'weight': 0.5,
                'fillOpacity': 0,
            },
            highlight_function=lambda feature: {'weight': 3, 'color': 'blue'},
            tooltip=folium.GeoJsonTooltip(
                fields=['CRESTA', 'EQ_AAL', 'AP', 'Count'],
                aliases=['CRESTA:', 'EQ_AAL:', 'AP:', 'Count:'],
                localize=True,
                sticky=True,
                labels=True,
                style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;"),
            )
        ).add_to(unprofitable_accumulation)

    else:
            
        #adding in top policies ISR
            
        # read in "N:\Natural Perils\Data\Exposures\ASPIRE\202407\risk_level_ISR_EQ.csv"
        risk_level_ISR_EQ = action_accumulation_locations

        #print sum of AP
        print(risk_level_ISR_EQ['AP'].sum())
        #print sum of TP
        print(risk_level_ISR_EQ['TP'].sum())
        print(risk_level_ISR_EQ['AP'].sum()/risk_level_ISR_EQ['TP'].sum())




        #pd.read_csv(r"N:\Natural Perils\Data\Exposures\ASPIRE\202407\risk_level_ISR_EQ.csv")
        #list all columns
        risk_level_ISR_EQ.columns
        #M_RP_WT = M_RP_ST + M_RP_HL + M_RP_CY
        risk_level_ISR_EQ['M_RP_WT'] = risk_level_ISR_EQ['M_RP_ST'] + risk_level_ISR_EQ['M_RP_HL'] + risk_level_ISR_EQ['M_RP_CY']

        #keep latitude and longitude
        risk_level_ISR_EQ = risk_level_ISR_EQ[['LATITUDE', 'LONGITUDE','SI','AP/TP','POLICY','AP','TP','RP','M_RP', 'M_RP_EQ', 'M_RP_FL','M_RP_BF', 'M_RP_WT','LIMIT_POLICY']]


        #summarise by POLICY
        Policy_sum = risk_level_ISR_EQ.groupby(['POLICY']).agg({
            'SI': 'sum',
            'AP': 'sum', 
            'TP': 'sum',
            'RP': 'sum',
            'M_RP': 'sum',
            'LATITUDE': 'count',
            'M_RP_EQ': 'sum',
            'M_RP_FL': 'sum',
            'M_RP_BF': 'sum',
            'M_RP_WT': 'sum',
            'LIMIT_POLICY': 'first'
        }).reset_index()

        #rename LATITUDE as COUNT
        Policy_sum = Policy_sum.rename(columns={'LATITUDE': 'COUNT'})

        #sort by COUNT descending
        Policy_sum = Policy_sum.sort_values(by='COUNT', ascending=False)

        #print sum of AP
        print(Policy_sum['AP'].sum())
        #print sum of TP
        print(Policy_sum['TP'].sum())
        print(Policy_sum['AP'].sum()/Policy_sum['TP'].sum())

        #calculate AP/TP
        Policy_sum['POLICY_AP/TP'] = Policy_sum['AP'] / Policy_sum['TP']
        #rename SI as POLICY_SI, AP as POLICY_AP, TP as POLICY_TP, COUNT as POLICY_COUNT
        Policy_sum = Policy_sum.rename(columns={'SI': 'POLICY_SI', 'AP': 'POLICY_AP', 'TP': 'POLICY_TP', 'COUNT': 'POLICY_COUNT','RP': 'POLICY_RP','M_RP': 'POLICY_M_RP', 'M_RP_EQ': 'POLICY_M_RP_EQ','M_RP_FL': 'POLICY_M_RP_FL','M_RP_BF': 'POLICY_M_RP_BF', 'M_RP_WT': 'POLICY_M_RP_WT'})

        #sort by POLICY_M_RP descending
        Policy_sum = Policy_sum.sort_values(by='POLICY_M_RP', ascending=False)


        Policy_sum_target = Policy_sum[Policy_sum['POLICY_M_RP'] > Policy_sum['POLICY_AP']]




        Policy_sum['Main Location'] =""

        #for each policy, find the CRESTA that has the highest total SI
        for policy in Policy_sum['POLICY']:
            policy_data = isr_risks[isr_risks['POLICY'] == policy]
            highest_cresta = policy_data.groupby('CRESTA')['SI'].sum().idxmax()
            Policy_sum.loc[Policy_sum['POLICY'] == policy, 'Main Location'] = highest_cresta

        #read in 'all_postcodes' sheet in "N:\Natural Perils\Data\Geographic\CRESTA\RMS Postcode to CRESTA mapping 2017 v2.xlsx"
        all_postcodes = pd.read_excel(r"N:\Natural Perils\Data\Geographic\CRESTA\RMS Postcode to CRESTA mapping 2017 v2.xlsx", sheet_name='all_postcodes')
        # keep unique CRESTA and CRESTA_name
        all_postcodes = all_postcodes[['CRESTA', 'CRESTA_NAME']]
        #drop duplicates
        all_postcodes = all_postcodes.drop_duplicates()

        #create "CRESTA Name" in Policy_sum by looking up CRESTA in all_postcodes
        Policy_sum = Policy_sum.merge(all_postcodes, left_on='Main Location', right_on='CRESTA', how='inner')



        #export to csv
        Policy_sum.to_csv(rf"N:\Natural Perils\Exposure Management\Monitoring_py\{mth}\Python\Top Marginal RI Policies.csv")

        #merge Policy_sum on risk_level_ISR_EQ by POLICY
        risk_level_ISR_EQ = risk_level_ISR_EQ.merge(Policy_sum_target, left_on='POLICY', right_on='POLICY', how='inner')
        # drop rows with missing POLICY_SI
        risk_level_ISR_EQ = risk_level_ISR_EQ.dropna(subset=['POLICY_SI'])


        print("Total AP in Action Segment ISR: ", risk_level_ISR_EQ['AP'].sum())

        # Add tooltips to the circles
        unprofitable_accumulation = folium.FeatureGroup(name='Action Segment: Unprofitable Accumulation', show=False)
        for i in range(0, len(risk_level_ISR_EQ)):
            folium.Circle(
            location=[risk_level_ISR_EQ.iloc[i]['LATITUDE'], risk_level_ISR_EQ.iloc[i]['LONGITUDE']],
            radius=400,
            color='red',
            fill=True,
            fill_color='red',
            tooltip=folium.Tooltip(
                f"Policy: {risk_level_ISR_EQ.iloc[i]['POLICY']}<br>"
                f"Policy AP/TP: {risk_level_ISR_EQ.iloc[i]['POLICY_AP/TP']:.2f}<br>"
                f"Policy SI: ${risk_level_ISR_EQ.iloc[i]['POLICY_SI'] / 1e6:.1f}M<br>"
                f"Policy AP: ${risk_level_ISR_EQ.iloc[i]['POLICY_AP'] / 1e3:.1f}K<br>"
                f"Count: {risk_level_ISR_EQ.iloc[i]['POLICY_COUNT'] :.0f}<br>"
                f"RI Premium: ${risk_level_ISR_EQ.iloc[i]['POLICY_RP'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium EQ: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_EQ'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium FL: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_FL'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium BF: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_BF'] / 1e3:.1f}K<br>"
                f"Marginal RI Premium WT: ${risk_level_ISR_EQ.iloc[i]['POLICY_M_RP_WT'] / 1e3:.1f}K",
                style=("background-color: white; border: 1px solid black; border-radius: 3px; box-shadow: 3px; font-size: 14px;")
            )
            ).add_to(unprofitable_accumulation)
        # unprofitable_accumulation.add_to(base_map)



    # -----------------------------------

    # unfunded_volatility = folium.FeatureGroup(name='Unfunded Volatility (pending)',show=False)
    # unfunded_volatility.add_to(base_map)


    # ------------------------------------------
    return unprofitable_accumulation









########################### SHARE #################




# gnaf_df=take_up_gnaf_df, region=region_select, Layer_shading_cap=0.4
def Take_Up_all(gnaf_df, region, Layer_AP_threshold, Layer_shading_cap):

    take_up_all_region = gnaf_df.groupby(region).agg(
        TOTAL_ALLIANZ_FLAG=('ALLIANZ_FLAG', 'sum'),
        SI=('SI', 'sum'),
        COUNT=('SI', 'count')
    ).reset_index()


    take_up_all_region['TAKE_UP'] = take_up_all_region['TOTAL_ALLIANZ_FLAG'] / take_up_all_region['COUNT']
    take_up_all_region.rename(columns={'COUNT': 'TOTAL_COUNT'}, inplace=True)
    take_up_all_region = take_up_all_region[[region, 'TAKE_UP', 'SI', 'TOTAL_COUNT']]

    take_up_all_region['TAKE_UP_SHADING'] = take_up_all_region['TAKE_UP'].clip(upper=Layer_shading_cap)

    take_up_all_region['TAKE_UP'] = take_up_all_region['TAKE_UP'].astype(float)
    take_up_all_region['TAKE_UP_LABEL'] = (take_up_all_region['TAKE_UP'] * 100).round(1).astype(str) + '%'
    take_up_all_region['SI_LABEL'] = take_up_all_region['SI'].map(lambda x: f"${x/1e3:1.2f}B")

    take_up_all_region[region] = take_up_all_region[region].astype(str)

    gdf_region = eval(rf'gdf_{region}')

    gdf_region[region] = gdf_region[region].astype(str)
    gdf_take_up_all = gdf_region.merge(take_up_all_region, on=region, how='left')

    gdf_take_up_all.dropna(subset=['TAKE_UP'], inplace=True)

    gdf_take_up_select = gdf_take_up_all[gdf_take_up_all['SI'] > Layer_AP_threshold/1e6]

    take_up_choropleth = folium.Choropleth(
        geo_data=gdf_take_up_select,
        data=gdf_take_up_select,
        columns=[region, 'TAKE_UP_SHADING'],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name='Take Up',
        nan_fill_opacity=0,
        show=False
    )
    take_up_choropleth.layer_name = rf'Take Up {region}'

    style_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    take_up_choropleth.geojson.add_child(
        folium.features.GeoJsonTooltip(
            fields=[region, 'TAKE_UP_LABEL', 'SI_LABEL'],
            aliases=[region, 'Take Up:', 'SI:'],
            style=("font-size: 14px;")
        )
    )
    # take_up_choropleth = gdf_take_up_all, 

    return take_up_choropleth, gdf_take_up_all





def Take_Up_Finder(df, s2_select, si_threshold, takeup_threshold, count_threshold, neighbours):
  
    #CHECK: double counting issue
    print('total allianz flag in')
    print(df['ALLIANZ_FLAG'].sum())

    level = s2_select
    def get_parent_cell_token_level_X(s2_token):
        cell_id = s2sphere.CellId.from_token(s2_token)  # Convert token to CellId
        parent_cell_id = cell_id.parent(level)  # Get the parent cell at level 10
        return parent_cell_id.to_token()  # Convert to token for easier handling
    
    def get_cell_id_from_token(s2_token):
        cell_id = s2sphere.CellId.from_token(s2_token)  # Convert token to CellId
        return cell_id.id()  # Get the cell ID

    df['S2_TK'] = df['S2_TK_12'].apply(get_parent_cell_token_level_X)
    df['S2_ID'] = df['S2_TK'].apply(get_cell_id_from_token)
    
    #CHECK: double counting issue
    print('total allianz flag df')
    print(df['ALLIANZ_FLAG'].sum())
    df['COUNT'] = 1
    print('total count df')
    print(df['COUNT'].sum())

    df_summary = df.groupby('S2_ID').agg({'SI': 'sum', 'ALLIANZ_FLAG': 'sum', 'COUNT': 'count'}).reset_index()

    #CHECK: double counting issue
    print('total allianz flag df_summary')
    print(df_summary['ALLIANZ_FLAG'].sum())
    print('total count df_summary')
    print(df_summary['COUNT'].sum())

    df_summary.rename(columns={'SI': 'SUM_SI', 'ALLIANZ_FLAG': 'SUM_ALLIANZ_FLAG', 'COUNT': 'COUNT'}, inplace=True)
    df_summary['TAKE_UP'] = df_summary['SUM_ALLIANZ_FLAG'] / df_summary['COUNT']

    df.drop(columns=['COUNT'])
    df2 = df.merge(df_summary, on='S2_ID', how='left')

    # "df_XX" datasets contain the individual points

    # keep rows where sum_allianz_flag > si_threshold and ALLIANZ_FLAG_PERC > takeup_threshold
    df4_threshold = df2[(df2['SUM_SI'] > si_threshold) & (df2['TAKE_UP'] > takeup_threshold) & (df2['ALLIANZ_FLAG'] > 0) & (df2['SUM_ALLIANZ_FLAG'] > count_threshold)]
    print(f"Found: {len(df4_threshold)}")
    print(f"Found Sum SI: {df4_threshold['SI'].sum()}")

    df_summary_select = df_summary[(df_summary['SUM_SI'] > si_threshold) & (df_summary['TAKE_UP'] > takeup_threshold) & (df_summary['SUM_ALLIANZ_FLAG'] > count_threshold)]

    if neighbours == 'Yes':
        # Identify neighbors of selected cells
        neighboring_s2_cells = set()
        for s2_id in df_summary_select['S2_ID']:
            cell_id = s2sphere.CellId(s2_id)
            neighbors = cell_id.get_all_neighbors(s2_select)
            for neighbor in neighbors:
                neighboring_s2_cells.add(neighbor.id())

        # Create a DataFrame for neighboring cells
        df_summary_neighbor = df_summary[df_summary['S2_ID'].isin(neighboring_s2_cells)]

        #set SI in df_summary_neighbor to 0
        df_summary_neighbor['SI_SHADING'] = 0

        df_summary_select['SI_SHADING'] = df_summary_select['SUM_SI']

        # Combine selected and neighboring cells
        df_summary_select = pd.concat([df_summary_select, df_summary_neighbor])
    else:
        df_summary_select['SI_SHADING'] = df_summary_select['SUM_SI']


    #create df4_threshold from rows of df2 that are in cells that are in df_summary_select
    df4_threshold = df2[(df2['S2_ID'].isin(df_summary_select['S2_ID'])) & (df2['ALLIANZ_FLAG'] > 0)]

    df5 = df4_threshold[['LONGITUDE', 'LATITUDE', 'SI']]

    plt.scatter(df4_threshold['LONGITUDE'], df4_threshold['LATITUDE'])
    plt.show()

    
    df_summary = df_summary.sort_values(by='TAKE_UP', ascending=False)
    
    #CHECK: double counting issue
    print(df_summary['COUNT'].sum())
    df_summary['SUM_SI'].sum()


    global S2_X
    S2_X = gpd.read_file(rf"N:\Natural Perils\Data\Geographic\S2 grids\S2_{s2_select}\S2_{s2_select}.gpkg")
    if S2_X.crs is None:
        S2_X.set_crs(7844, inplace=True)
    S2_X = S2_X.to_crs(7844)
    S2_X.crs   # 7844 is in degrees 9473 distance
    S2_X = S2_X[['S2_ID', 'geometry']]
    S2_X['S2_ID'] = S2_X['S2_ID'].astype(str)
    df_summary_select['S2_ID'] = df_summary_select['S2_ID'].astype(str)
    
    S2_X = S2_X.merge(df_summary_select, left_on='S2_ID', right_on='S2_ID', how='left')
    S2_X = S2_X[['geometry', 'S2_ID', 'SUM_SI', 'TAKE_UP', 'COUNT', 'SUM_ALLIANZ_FLAG', 'SI_SHADING']]
    S2_X = S2_X.dropna(subset=['TAKE_UP'])
 
    S2_X['COUNT'] = S2_X['COUNT'] / 1000
    S2_X['COUNT'] = S2_X['COUNT'].map(lambda x: f"{x:1.0f}K")
    S2_X['SUM_SI_LABEL'] = S2_X['SUM_SI'].map(lambda x: f"${x:1.0f}M")
    S2_X['TAKE_UP_LABEL'] = S2_X['TAKE_UP'].map(lambda x: f"{x*100:.0f}%")


    #cap SUM_SI to 250 for choropleth
    S2_X['SUM_SI'] = S2_X['SUM_SI'].clip(upper=250)

    print(f"Number of rows in S2_X: {len(S2_X)}")
    



    return S2_X, df4_threshold, df_summary




def create_take_up_heat(s2_select): 

    heat_points = rf'df_{s2_select}'

    if heat_points is not None:
        heat_data = [[row['LATITUDE'], row['LONGITUDE']] for index, row in heat_points.iterrows()]
        Heatmap = HeatMap(heat_data, show=False, radius=5, blur=3)
        Heatmap.layer_name = f'HeatMap_S2_{s2_select}'

    return Heatmap



######### old
def create_take_up_heat(heat_points, s2_select): 

    heat_points = rf'df_{s2_select}'

    if heat_points is not None:
        heat_data = [[row['LATITUDE'], row['LONGITUDE']] for index, row in heat_points.iterrows()]
        Heatmap = HeatMap(heat_data, show=False, radius=5, blur=3)
        Heatmap.layer_name = f'HeatMap_S2_{s2_select}'

    return Heatmap




def create_take_up_layer(S2_X, shading, name, neighbours_SI, Take_Up_Shading_Cap, heat_points):
    
    
    

    if heat_points is not None:
        heat_data = [[row['LATITUDE'], row['LONGITUDE']] for index, row in heat_points.iterrows()]
        Heatmap = HeatMap(heat_data, show=False, radius=5, blur=3)
        Heatmap.layer_name = f'HeatMap_S2_{name}'





    S2_X['TAKE_UP'] = S2_X['TAKE_UP'].clip(upper=Take_Up_Shading_Cap)

    # apply neighbour conditions 
    #drop rows in df_summary_select where SUM_SI is less than si_threshold/4 and SUM_ALLIANZ_FLAG is less than count_threshold/4
    S2_X = S2_X[(S2_X['SUM_SI'] > neighbours_SI)]

    if shading == 'SI':
        S2_layerX = folium.Choropleth(
            geo_data=S2_X,
            data=S2_X,
            columns=['S2_ID', 'SI_SHADING'],
            key_on='feature.properties.S2_ID',
            fill_color='Reds',  
            fill_opacity=0.5,
            line_opacity=0.2,
            nan_fill_color='transparent', 
            show=False,
            legend_name= name
        )
        S2_layerX.layer_name = name
        highlight_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
        S2_layerX.geojson.add_child(
            folium.features.GeoJsonTooltip(
                fields=['SUM_SI_LABEL', 'SUM_ALLIANZ_FLAG', 'TAKE_UP_LABEL', 'S2_ID'],
                aliases=[
                    'SI:',
                    'Count Allianz',
                    'Take Up:', 
                    'S2_ID:'
                ],
                style=("font-size: 14px;")
            )
        )
    else:
        S2_layerX = folium.Choropleth(
            geo_data=S2_X,
            data=S2_X,
            columns=['S2_ID', 'TAKE_UP'],
            key_on='feature.properties.S2_ID',
            fill_color='Reds',  
            fill_opacity=0.5,
            line_opacity=0.2,
            nan_fill_color='transparent', 
            show=False,
            legend_name= name
        )
        S2_layerX.layer_name = name
        highlight_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
        S2_layerX.geojson.add_child(
            folium.features.GeoJsonTooltip(
                fields=['SUM_SI_LABEL', 'SUM_ALLIANZ_FLAG', 'TAKE_UP_LABEL', 'S2_ID'],
                aliases=[
                    'SI:',
                    'Count Allianz',
                    'Take Up:', 
                    'S2_ID:'
                ],
                style=("font-size: 14px;")
            )
        )

        # Add heatmap to the S2_layerX
        if heat_points is not None:
            heat_data = [[row['LATITUDE'], row['LONGITUDE']] for index, row in heat_points.iterrows()]
            heat_layer = HeatMap(heat_data, radius=5, blur=3, show=False)
            heat_layer.add_to(S2_layerX.geojson)

    return S2_layerX










def take_up(take_up_df, region):

    take_up_df['TAKE_UP'] = take_up_df['Allianz'] / take_up_df['PSMA']
    take_up_df['TAKE_UP_CLIP'] = take_up_df['TAKE_UP'].clip(upper=0.2)
    take_up_df['TAKE_UP'] = take_up_df['TAKE_UP'].round(2)
    take_up_df['TAKE_UP'] = (take_up_df['TAKE_UP']*100)
    take_up_df['TAKE_UP'] = take_up_df['TAKE_UP'].fillna(0)
    take_up_df['TAKE_UP'] = take_up_df['TAKE_UP'].astype(int).astype(str) + '%'

    gdf_region = eval(rf'gdf_{region}')
    
    gdf_region = gdf_region.merge(take_up_df, on=region, how='left')
    gdf_region = gdf_region[[region, 'geometry', 'TAKE_UP', 'TAKE_UP_CLIP']]#, region_name]]

    take_up = folium.Choropleth(
        geo_data=gdf_region,
        data=gdf_region,
        columns=[region, 'TAKE_UP_CLIP'],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name='Take Up',
        layer_name='Take Up',
        nan_fill_opacity=0,  # This makes missing SA3s transparent
        show=False
    )
    take_up.layer_name = 'Take Up'

    style_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    take_up.geojson.add_child(
        folium.features.GeoJsonTooltip(
            fields=[region, 'TAKE_UP'],
            aliases=[region, 'Take Up'],
            style=("font-size: 14px;")
        )
    )

    return layer_take_up, take_up_df


def market_share(market_share_df, region, peril):

    market_share_df = market_share_df.groupby(region).sum().reset_index()

    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'Allianz_{peril}'] / market_share_df[f'Industry_{peril}']
    
    #cap MARKET_SHARE for map shading
    market_share_df[f'MARKET_SHARE_{peril}_CLIP'] = market_share_df[f'MARKET_SHARE_{peril}'].clip(upper=0.33)
   
    #formatting
    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'MARKET_SHARE_{peril}'].round(2)
    market_share_df[f'MARKET_SHARE_{peril}'] = (market_share_df[f'MARKET_SHARE_{peril}']*100)
    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'MARKET_SHARE_{peril}'].fillna(0)
    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'MARKET_SHARE_{peril}'].astype(int).astype(str) + '%'

    market_share_df[region] = market_share_df[region].astype(int)

    gdf_region = eval(rf'gdf_{region}')

    gdf_region[region] = gdf_region[region].astype(int)

    gdf_region = gdf_region.merge(market_share_df, on=region, how='left')
    gdf_region = gdf_region[[region, 'geometry', f'MARKET_SHARE_{peril}', f'MARKET_SHARE_{peril}_CLIP']]#, region_name]]

    market_share = folium.Choropleth(
        geo_data=gdf_region,
        data=gdf_region,
        columns=[region, f'MARKET_SHARE_{peril}_CLIP'],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name=f'Market Share {peril}',
        layer_name = f'Market Share {peril}',
        nan_fill_opacity=0,  
        show=False
    )
    market_share.layer_name = f'Market Share {peril}'
    style_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    highlight_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    market_share.geojson.add_child(
        folium.features.GeoJsonTooltip(
            fields=[region, f'MARKET_SHARE_{peril}'], 
            aliases=[region, f'Market Share {peril}'],
            style=("font-size: 14px;")
        )
    )

    return market_share



# ###############
# def create_3d_choropleth_layer(df_summary_select, s2_select, base_map):
#     # Read the GeoDataFrame
#     S2_X = gpd.read_file(
#         rf"N:\Natural Perils\Data\Geographic\S2 grids\S2_{s2_select}\S2_{s2_select}.gpkg"
#     )
    
#     # If CRS is missing, set it; then reproject if needed:
#     if S2_X.crs is None:
#         S2_X.set_crs(7844, inplace=True)
    
#     # Typically you'd use EPSG:4326 for lat-lon, but if 7844 works for Mapbox, keep it:
#     # Otherwise, do: S2_X = S2_X.to_crs(epsg=4326)
#     S2_X = S2_X.to_crs(7844)
    
#     # Keep only relevant columns, ensure ID is string
#     S2_X = S2_X[['S2_ID', 'geometry']]
#     S2_X['S2_ID'] = S2_X['S2_ID'].astype(str)
#     df_summary_select['S2_ID'] = df_summary_select['S2_ID'].astype(str)
    
#     # Merge data
#     S2_X = S2_X.merge(df_summary_select, on='S2_ID', how='left')
    
#     # Convert to GeoJSON FeatureCollection for Plotly
#     geojson_data = json.loads(S2_X.to_json())

#     # Build the Choroplethmapbox figure
#     fig = go.Figure(go.Choroplethmapbox(
#         geojson=geojson_data,
#         # Use the property name within each GeoJSON feature
#         featureidkey='properties.S2_ID',
#         locations=S2_X['S2_ID'],     # Match with S2_ID
#         z=S2_X['SUM_SI'],           # Colors
#         text=S2_X['TAKE_UP'],       # Will appear in hover
#         colorscale="YlOrRd",
#         marker_opacity=0.5,
#         marker_line_width=0,
#         hoverinfo='location+z+text'
#     ))

#     # Update layout
#     fig.update_layout(
#         mapbox_style="carto-positron",
#         mapbox_zoom=3,
#         mapbox_center={"lat": -28.0, "lon": 134.0},
#         height=600,
#         margin={"r":0, "t":0, "l":0, "b":0}
#     )

#     # Convert Plotly figure to HTML, embed in Folium popup
#     fig_html = fig.to_html(full_html=False)
#     iframe = folium.IFrame(fig_html, width=700, height=500)
#     popup = folium.Popup(iframe, max_width=2650)
#     folium.Marker(location=[-28.0, 134.0], popup=popup).add_to(base_map)

#     return base_map


################################### 






################# CATCUBE




# ---- geocode functions -------
# set_geocode_source
# check_GNAF_validity - helper function
# geocode
# enrich_by_region  - used for enriching with SA3 region
# enrich_S2 - adds S2_TK_12


# ---- enrichment functions -------
# enrich_single  - helper function
# enrich


def list_functions():
    return ['list_functions', 'set_geocode_source', 'check_GNAF_validity', 'geocoder', 'geocode_SA3', 'geocode_postcode', 'geocode_S2_12', 'enrich_single', 'enrich']


# Geocode functions -------------------------------------------------------------------------


# creates a GEOCODE_KEY ready for matching, from a dataset of correspondences between GNAF and latlongs
# #either postcode CHIP average latlongs, postcode centoid, or lookup postcode default (80th percentile)
def set_geocode_source(geocode):
    # Rename DETAIL_PID to GNAF
    geocode.rename(columns={'DETAIL_PID': 'GNAF'}, inplace=True)
    # If postcode is missing set to 9999
    geocode['POSTCODE'] = geocode['POSTCODE'].fillna(9999).astype(int)
    # Take first row of each GNAF
    geocode = geocode.groupby('GNAF').first().reset_index()
    # Summarize average latitude and longitude by postcode
    geocode_postcode = geocode.groupby('POSTCODE').agg({'LATITUDE': 'mean', 'LONGITUDE': 'mean'}).reset_index()
    geocode_postcode['CONFIDENCE'] = 9
    # Concatenate geocode_postcode to geocode
    geocode = pd.concat([geocode, geocode_postcode], ignore_index=True)
    # Create GEOCODE_KEY
    geocode['GEOCODE_KEY'] = np.where(geocode['GNAF'].isna(),
                                        'POSTCODE_' + geocode['POSTCODE'].astype(str),
                                        geocode['GNAF'])
    return geocode



def check_GNAF_validity(df, geocode, postcode_default="POSTCODE_2000"):
    # Check if GEOCODE_KEY from df is in geocode
    missing_keys = ~df['GEOCODE_KEY'].isin(geocode['GEOCODE_KEY'])
    # Replace GEOCODE_KEY with "POSTCODE_" + POSTCODE if not in geocode
    df.loc[missing_keys, 'GEOCODE_KEY'] = 'POSTCODE_' + df.loc[missing_keys, 'POSTCODE']
    
    num_replacements_1 = missing_keys.sum()

    #if GEOCODE_KEY is still not in geocode, replace with postcode_default
    missing_keys = ~df['GEOCODE_KEY'].isin(geocode['GEOCODE_KEY'])
    df.loc[missing_keys, 'GEOCODE_KEY'] = postcode_default

    num_replacements_2 = missing_keys.sum()
    
    return df, num_replacements_1 + num_replacements_2 



#creates a GEOCODE_KEY for the input dataset and merges it with the geocode - for latlongs
def geocoder(df, geocode, postcode_default="POSTCODE_2000"):

    # 1st step: create GEOCODE_KEY and use postcode for missing gnafs
    df['GNAF'] = df['GNAF'].str.strip().fillna('')
    df['POSTCODE'] = df['POSTCODE'].astype(str).str.strip().fillna('')

    #GEOCODE_KEY = coalesce(GNAF, POSTCODE)
    df['GEOCODE_KEY'] = np.where(df['GNAF'] == '', 
                                'POSTCODE_' + df['POSTCODE'],
                                df['GNAF'])
    
    df, fixes = check_GNAF_validity(df, geocode, postcode_default="POSTCODE_2000")
    print(f"Number of GEOCODE_KEY replacements: {fixes}")

    geocode = geocode.drop(columns=['GNAF'])
    geocode.rename(columns={'POSTCODE':'GEOCODE_POSTCODE'}, inplace=True)

    df = df.merge(geocode, left_on='GEOCODE_KEY', right_on='GEOCODE_KEY', how='left')
    
    # check merge
    missing_latitudes = df[df['LATITUDE'].isnull()]
    return df, missing_latitudes



def geocode_SA3(df):

    if 'index_right' in df.columns:
        df = df.drop(columns=['index_right'])

    gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['LONGITUDE'], df['LATITUDE']))

    sa3 = gpd.read_file(r"N:\Natural Perils\Data\Geographic\ABS\SA3\SA3_2021_AUST_GDA2020.shp")
    sa3 = sa3.rename(columns={"SA3_CODE21": "SA3", "SA3_NAME21": "SA3_NAME"})
    sa3["SA3"] = sa3["SA3"].replace("ZZZZZ", 99999)
    sa3["SA3"] = sa3["SA3"].astype(int)
    sa3 = sa3[["SA3", "SA3_NAME", "geometry"]]

    gdf.sindex
    sa3.sindex
    result_df = gpd.sjoin(gdf, sa3, how="left", predicate='within')

    result_df[result_df["SA3"].isnull()]
    result_df["SA3"] = result_df["SA3"].fillna(99999)
    result_df["SA3"] = result_df["SA3"].astype(int)

    print(result_df.head())

    return result_df


def geocode_postcode(df):

    if 'index_right' in df.columns:
        df = df.drop(columns=['index_right'])

    gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['LONGITUDE'], df['LATITUDE']))

    sa3 = gpd.read_file(r"N:\Natural Perils\Data\Geographic\ABS\nonABS structures\Postcodes\POA_2021_AUST_GDA2020.shp")
    sa3 = sa3.rename(columns={"POA_CODE21": "POSTCODE"})
    sa3["POSTCODE"] = sa3["POSTCODE"].replace("ZZZZ", 9999)
    sa3["POSTCODE"] = sa3["POSTCODE"].astype(int)
    sa3 = sa3[["POSTCODE", "geometry"]]

    gdf.sindex
    sa3.sindex
    result_df = gpd.sjoin(gdf, sa3, how="left", predicate='within')

    result_df[result_df["POSTCODE"].isnull()]
    result_df["POSTCODE"] = result_df["POSTCODE"].fillna(9999)
    result_df["POSTCODE"] = result_df["POSTCODE"].astype(int)

    print(result_df.head())

    return result_df


#all other levels are look ups from the S2_12 level
def geocode_S2_12(df):
    
    df['S2_TK_12'] = df.apply(lambda x: s2sphere.CellId.from_lat_lng(s2sphere.LatLng.from_degrees(x['LATITUDE'], x['LONGITUDE'])).parent(12).to_token(), axis=1)
    
    return df



# enrichment functions -------------------------------------------------------------------------
# for Hazard enrichment, and Accumulation enrichment ------------------------------


def enrich_single(df, map):

    df = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['LONGITUDE'], df['LATITUDE']))
    # Spatial join df and gdf_bf
    #if index_right is in df then delete it
    if 'index_right' in df.columns:
        df = df.drop(columns=['index_right'])
    df_enriched = gpd.sjoin(df, map, how='left')
    df_enriched = df_enriched.drop(columns=['index_right', 'geometry'])
    
    # Check for missing joins
    missing = df_enriched.isnull().sum()
    return df_enriched, missing



def enrich(df, *maps):
    missing_total = pd.Series(dtype=int)
    for map in maps:
        df, missing = enrich_single(df, map)
        missing_total = missing_total.add(missing, fill_value=0)
    return df, missing_total