
import hmac
import hashlib
import json
import datetime
import os

SECRET_KEY = b"SuperSecretKey123"
LICENSE_FILE = os.path.join(os.path.dirname(__file__), "license.json")

def validate_license():
    try:
        with open(LICENSE_FILE, "r") as f:
            data = json.load(f)

        payload = data["payload"]
        signature = data["signature"]

        message = json.dumps(payload, sort_keys=True).encode()
        expected_sig = hmac.new(SECRET_KEY, message, hashlib.sha256).hexdigest()

        if not hmac.compare_digest(expected_sig, signature):
            raise ValueError("Invalid license signature.")

        expiry_date = datetime.datetime.strptime(payload["expires"], "%Y-%m-%d").date()
        if expiry_date < datetime.datetime.now().date():
            raise RuntimeError("License has expired.")

    except Exception as e:
        raise RuntimeError(f"License validation failed: {e}")

validate_license()
