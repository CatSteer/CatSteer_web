
# Initialization with offline license validation

import os, json, hmac, hashlib, datetime

_secret = b'Allianz123'
_license_path = os.path.join(os.path.dirname(__file__), "license.json")

with open(_license_path, "r") as _f:
    _data = json.load(_f)

_msg = json.dumps(_data["payload"], sort_keys=True).encode()
_sig = hmac.new(_secret, _msg, hashlib.sha256).hexdigest()

if _sig != _data["signature"]:
    raise RuntimeError("❌ Invalid license signature.")

_expiry = datetime.datetime.strptime(_data["payload"]["expires"], "%Y-%m-%d").date()
if datetime.date.today() > _expiry:
    raise RuntimeError(f"❌ License expired on {_expiry}.")
