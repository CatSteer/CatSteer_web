#functions_CatShare

# import pandas as pd
# import s2sphere
# # import matplotlib.pyplot as plt
# import folium
# from folium.plugins import HeatMap
# import geopandas as gpd
# import plotly.express as px
# import plotly.graph_objs as go
# import copy
# import json
# import plotly.graph_objects as go



#Take Up Finder layers
# SX_12, df_12, S2_12_summary = Take_Up_Finder(take_up_gnaf_df,s2_select=12, si_threshold=75, takeup_threshold=0.245, count_threshold=40, neighbours='Yes')
# SX_10, df_10, S2_10_summary = Take_Up_Finder(take_up_gnaf_df,s2_select=10, si_threshold=50, takeup_threshold=0.30, count_threshold=5, neighbours='Yes')
# take_up_finder = create_take_up_layer(S2_X=SX_10, shading='Take Up', name=f'Take Up Grid_S2_10', neighbours_SI=50, Take_Up_Shading_Cap=0.30)
# take_up_heat = create_take_up_heat(heat_points=df_10, s2_select=10)

# take_up_finder.add_to(base_map)
# take_up_heat.add_to(base_map)


#market share postcode/SA layers
# layer_market_share_df = pd.read_excel(market_file_path, sheet_name='MarketShare')          # take_up_df = pd.read_excel(market_file_path, sheet_name='TakeUp')
# layer_market_share_EQ = market_share(market_share_df, region_select, region_select_gdf, 'EQ')      # take_up = take_up(take_up_df, region_select, region_select_gdf)
# layer_market_share_FL = market_share(market_share_df, region_select, region_select_gdf, 'FL')

# layer_market_share_EQ.add_to(base_map)
# layer_market_share_FL.add_to(base_map)
# layer_take_up.add_to(base_map)


def list_functions():
    return ['list_functions', 'Take_Up_all', 'Take_Up_Finder', 'create_take_up_heat', 'create_take_up_layer', 'take_up', 'market_share']



def save(base_map, html_save):
    base_map_dup = copy.deepcopy(base_map)
    folium.LayerControl(collapsed=False).add_to(base_map_dup)
    base_map_dup.save(html_save)

# gnaf_df=take_up_gnaf_df, region=region_select, Layer_shading_cap=0.4
def Take_Up_all(gnaf_df, region, Layer_AP_threshold, Layer_shading_cap):

    take_up_all_region = gnaf_df.groupby(region).agg(
        TOTAL_ALLIANZ_FLAG=('ALLIANZ_FLAG', 'sum'),
        SI=('SI', 'sum'),
        COUNT=('SI', 'count')
    ).reset_index()


    take_up_all_region['TAKE_UP'] = take_up_all_region['TOTAL_ALLIANZ_FLAG'] / take_up_all_region['COUNT']
    take_up_all_region.rename(columns={'COUNT': 'TOTAL_COUNT'}, inplace=True)
    take_up_all_region = take_up_all_region[[region, 'TAKE_UP', 'SI', 'TOTAL_COUNT']]

    take_up_all_region['TAKE_UP_SHADING'] = take_up_all_region['TAKE_UP'].clip(upper=Layer_shading_cap)

    take_up_all_region['TAKE_UP'] = take_up_all_region['TAKE_UP'].astype(float)
    take_up_all_region['TAKE_UP_LABEL'] = (take_up_all_region['TAKE_UP'] * 100).round(1).astype(str) + '%'
    take_up_all_region['SI_LABEL'] = take_up_all_region['SI'].map(lambda x: f"${x/1e9:1.1f}B")

    take_up_all_region[region] = take_up_all_region[region].astype(str)

    gdf_region = eval(rf'gdf_{region}')

    gdf_region[region] = gdf_region[region].astype(str)
    gdf_take_up_all = gdf_region.merge(take_up_all_region, on=region, how='left')

    gdf_take_up_all.dropna(subset=['TAKE_UP'], inplace=True)

    gdf_take_up_select = gdf_take_up_all[gdf_take_up_all['SI'] > Layer_AP_threshold/1e6]

    take_up_choropleth = folium.Choropleth(
        geo_data=gdf_take_up_select,
        data=gdf_take_up_select,
        columns=[region, 'TAKE_UP_SHADING'],
        key_on=f'feature.properties.{region}',
        fill_color='YlOrRd',
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name='Take Up',
        nan_fill_opacity=0,
        show=False
    )
    take_up_choropleth.layer_name = 'Take Up'

    style_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    take_up_choropleth.geojson.add_child(
        folium.features.GeoJsonTooltip(
            fields=[region, 'TAKE_UP_LABEL', 'SI_LABEL'],
            aliases=[region, 'Take Up:', 'SI:'],
            style=("font-size: 14px;")
        )
    )
    # take_up_choropleth = gdf_take_up_all, 

    return take_up_choropleth, gdf_take_up_all




def Take_Up_Finder(df, s2_select, si_threshold, takeup_threshold, count_threshold, neighbours):
  
    #CHECK: double counting issue
    print('total allianz flag in')
    print(df['ALLIANZ_FLAG'].sum())

    level = s2_select
    def get_parent_cell_token_level_X(s2_token):
        cell_id = s2sphere.CellId.from_token(s2_token)  # Convert token to CellId
        parent_cell_id = cell_id.parent(level)  # Get the parent cell at level 10
        return parent_cell_id.to_token()  # Convert to token for easier handling
    
    def get_cell_id_from_token(s2_token):
        cell_id = s2sphere.CellId.from_token(s2_token)  # Convert token to CellId
        return cell_id.id()  # Get the cell ID

    df['S2_TK'] = df['S2_TK_12'].apply(get_parent_cell_token_level_X)
    df['S2_ID'] = df['S2_TK'].apply(get_cell_id_from_token)
    
    #CHECK: double counting issue
    print('total allianz flag df')
    print(df['ALLIANZ_FLAG'].sum())
    df['COUNT'] = 1
    print('total count df')
    print(df['COUNT'].sum())

    df_summary = df.groupby('S2_ID').agg({'SI': 'sum', 'ALLIANZ_FLAG': 'sum', 'COUNT': 'count'}).reset_index()

    #CHECK: double counting issue
    print('total allianz flag df_summary')
    print(df_summary['ALLIANZ_FLAG'].sum())
    print('total count df_summary')
    print(df_summary['COUNT'].sum())

    df_summary.rename(columns={'SI': 'SUM_SI', 'ALLIANZ_FLAG': 'SUM_ALLIANZ_FLAG', 'COUNT': 'COUNT'}, inplace=True)
    df_summary['TAKE_UP'] = df_summary['SUM_ALLIANZ_FLAG'] / df_summary['COUNT']

    df.drop(columns=['COUNT'])
    df2 = df.merge(df_summary, on='S2_ID', how='left')

    # "df_XX" datasets contain the individual points

    # keep rows where sum_allianz_flag > si_threshold and ALLIANZ_FLAG_PERC > takeup_threshold
    df4_threshold = df2[(df2['SUM_SI'] > si_threshold) & (df2['TAKE_UP'] > takeup_threshold) & (df2['ALLIANZ_FLAG'] > 0) & (df2['SUM_ALLIANZ_FLAG'] > count_threshold)]
    print(f"Found: {len(df4_threshold)}")
    print(f"Found Sum SI: {df4_threshold['SI'].sum()}")

    df_summary_select = df_summary[(df_summary['SUM_SI'] > si_threshold) & (df_summary['TAKE_UP'] > takeup_threshold) & (df_summary['SUM_ALLIANZ_FLAG'] > count_threshold)]

    if neighbours == 'Yes':
        # Identify neighbors of selected cells
        neighboring_s2_cells = set()
        for s2_id in df_summary_select['S2_ID']:
            cell_id = s2sphere.CellId(s2_id)
            neighbors = cell_id.get_all_neighbors(s2_select)
            for neighbor in neighbors:
                neighboring_s2_cells.add(neighbor.id())

        # Create a DataFrame for neighboring cells
        df_summary_neighbor = df_summary[df_summary['S2_ID'].isin(neighboring_s2_cells)]

        #set SI in df_summary_neighbor to 0
        df_summary_neighbor['SI_SHADING'] = 0

        df_summary_select['SI_SHADING'] = df_summary_select['SUM_SI']

        # Combine selected and neighboring cells
        df_summary_select = pd.concat([df_summary_select, df_summary_neighbor])
    else:
        df_summary_select['SI_SHADING'] = df_summary_select['SUM_SI']


    #create df4_threshold from rows of df2 that are in cells that are in df_summary_select
    df4_threshold = df2[(df2['S2_ID'].isin(df_summary_select['S2_ID'])) & (df2['ALLIANZ_FLAG'] > 0)]

    df5 = df4_threshold[['LONGITUDE', 'LATITUDE', 'SI']]

    plt.scatter(df4_threshold['LONGITUDE'], df4_threshold['LATITUDE'])
    plt.show()

    
    df_summary = df_summary.sort_values(by='TAKE_UP', ascending=False)
    
    #CHECK: double counting issue
    print(df_summary['COUNT'].sum())
    df_summary['SUM_SI'].sum()


    global S2_X
    S2_X = gpd.read_file(rf"N:\Natural Perils\Data\Geographic\S2 grids\S2_{s2_select}\S2_{s2_select}.gpkg")
    if S2_X.crs is None:
        S2_X.set_crs(7844, inplace=True)
    S2_X = S2_X.to_crs(7844)
    S2_X.crs   # 7844 is in degrees 9473 distance
    S2_X = S2_X[['S2_ID', 'geometry']]
    S2_X['S2_ID'] = S2_X['S2_ID'].astype(str)
    df_summary_select['S2_ID'] = df_summary_select['S2_ID'].astype(str)
    
    S2_X = S2_X.merge(df_summary_select, left_on='S2_ID', right_on='S2_ID', how='left')
    S2_X = S2_X[['geometry', 'S2_ID', 'SUM_SI', 'TAKE_UP', 'COUNT', 'SUM_ALLIANZ_FLAG', 'SI_SHADING']]
    S2_X = S2_X.dropna(subset=['TAKE_UP'])
 
    S2_X['COUNT'] = S2_X['COUNT'] / 1000
    S2_X['COUNT'] = S2_X['COUNT'].map(lambda x: f"{x:1.0f}K")
    S2_X['SUM_SI_LABEL'] = S2_X['SUM_SI'].map(lambda x: f"${x:1.0f}M")
    S2_X['TAKE_UP_LABEL'] = S2_X['TAKE_UP'].map(lambda x: f"{x*100:.0f}%")


    #cap SUM_SI to 250 for choropleth
    S2_X['SUM_SI'] = S2_X['SUM_SI'].clip(upper=250)

    print(f"Number of rows in S2_X: {len(S2_X)}")
    
    return S2_X, df4_threshold, df_summary

def create_take_up_heat(heat_points, s2_select): 

    if heat_points is not None:
        heat_data = [[row['LATITUDE'], row['LONGITUDE']] for index, row in heat_points.iterrows()]
        Heatmap = HeatMap(heat_data, show=False, radius=5, blur=3)
        Heatmap.layer_name = f'HeatMap_S2_{s2_select}'

    return Heatmap

def create_take_up_layer(S2_X, shading, name, neighbours_SI, Take_Up_Shading_Cap):
    
    S2_X['TAKE_UP'] = S2_X['TAKE_UP'].clip(upper=Take_Up_Shading_Cap)

    # apply neighbour conditions 
    #drop rows in df_summary_select where SUM_SI is less than si_threshold/4 and SUM_ALLIANZ_FLAG is less than count_threshold/4
    S2_X = S2_X[(S2_X['SUM_SI'] > neighbours_SI)]

    if shading == 'SI':
        S2_layerX = folium.Choropleth(
            geo_data=S2_X,
            data=S2_X,
            columns=['S2_ID', 'SI_SHADING'],
            key_on='feature.properties.S2_ID',
            fill_color='YlOrRd',  
            fill_opacity=0.5,
            line_opacity=0.2,
            nan_fill_color='transparent', 
            show=False,
            legend_name= name
        )
        S2_layerX.layer_name = name
        highlight_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
        S2_layerX.geojson.add_child(
            folium.features.GeoJsonTooltip(
                fields=['SUM_SI_LABEL', 'SUM_ALLIANZ_FLAG', 'TAKE_UP_LABEL', 'S2_ID'],
                aliases=[
                    'SI:',
                    'Count Allianz',
                    'Take Up:', 
                    'S2_ID:'
                ],
                style=("font-size: 14px;")
            )
        )
    else:
        S2_layerX = folium.Choropleth(
            geo_data=S2_X,
            data=S2_X,
            columns=['S2_ID', 'TAKE_UP'],
            key_on='feature.properties.S2_ID',
            fill_color='YlOrRd',  
            fill_opacity=0.5,
            line_opacity=0.2,
            nan_fill_color='transparent', 
            show=False,
            legend_name= name
        )
        S2_layerX.layer_name = name
        highlight_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
        S2_layerX.geojson.add_child(
            folium.features.GeoJsonTooltip(
                fields=['SUM_SI_LABEL', 'SUM_ALLIANZ_FLAG', 'TAKE_UP_LABEL', 'S2_ID'],
                aliases=[
                    'SI:',
                    'Count Allianz',
                    'Take Up:', 
                    'S2_ID:'
                ],
                style=("font-size: 14px;")
            )
        )

    return S2_layerX

def take_up(take_up_df, region):

    take_up_df['TAKE_UP'] = take_up_df['Allianz'] / take_up_df['PSMA']
    take_up_df['TAKE_UP_CLIP'] = take_up_df['TAKE_UP'].clip(upper=0.2)
    take_up_df['TAKE_UP'] = take_up_df['TAKE_UP'].round(2)
    take_up_df['TAKE_UP'] = (take_up_df['TAKE_UP']*100)
    take_up_df['TAKE_UP'] = take_up_df['TAKE_UP'].fillna(0)
    take_up_df['TAKE_UP'] = take_up_df['TAKE_UP'].astype(int).astype(str) + '%'

    gdf_region = eval(rf'gdf_{region}')
    
    gdf_region = gdf_region.merge(take_up_df, on=region, how='left')
    gdf_region = gdf_region[[region, 'geometry', 'TAKE_UP', 'TAKE_UP_CLIP']]#, region_name]]

    take_up = folium.Choropleth(
        geo_data=gdf_region,
        data=gdf_region,
        columns=[region, 'TAKE_UP_CLIP'],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name='Take Up',
        layer_name='Take Up',
        nan_fill_opacity=0,  # This makes missing SA3s transparent
        show=False
    )
    take_up.layer_name = 'Take Up'

    style_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    take_up.geojson.add_child(
        folium.features.GeoJsonTooltip(
            fields=[region, 'TAKE_UP'],
            aliases=[region, 'Take Up'],
            style=("font-size: 14px;")
        )
    )

    return layer_take_up, take_up_df


def market_share(market_share_df, region, peril):

    market_share_df = market_share_df.groupby(region).sum().reset_index()

    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'Allianz_{peril}'] / market_share_df[f'Industry_{peril}']
    
    #cap MARKET_SHARE for map shading
    market_share_df[f'MARKET_SHARE_{peril}_CLIP'] = market_share_df[f'MARKET_SHARE_{peril}'].clip(upper=0.33)
   
    #formatting
    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'MARKET_SHARE_{peril}'].round(2)
    market_share_df[f'MARKET_SHARE_{peril}'] = (market_share_df[f'MARKET_SHARE_{peril}']*100)
    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'MARKET_SHARE_{peril}'].fillna(0)
    market_share_df[f'MARKET_SHARE_{peril}'] = market_share_df[f'MARKET_SHARE_{peril}'].astype(int).astype(str) + '%'

    market_share_df[region] = market_share_df[region].astype(int)

    gdf_region = eval(rf'gdf_{region}')

    gdf_region[region] = gdf_region[region].astype(int)

    gdf_region = gdf_region.merge(market_share_df, on=region, how='left')
    gdf_region = gdf_region[[region, 'geometry', f'MARKET_SHARE_{peril}', f'MARKET_SHARE_{peril}_CLIP']]#, region_name]]

    market_share = folium.Choropleth(
        geo_data=gdf_region,
        data=gdf_region,
        columns=[region, f'MARKET_SHARE_{peril}_CLIP'],
        key_on=f'feature.properties.{region}',
        fill_color='Reds',
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name=f'Market Share {peril}',
        layer_name = f'Market Share {peril}',
        nan_fill_opacity=0,  
        show=False
    )
    market_share.layer_name = f'Market Share {peril}'
    style_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    highlight_function = lambda x: {'fillColor': 'green', 'color': 'green', 'fillOpacity': 0.7}
    market_share.geojson.add_child(
        folium.features.GeoJsonTooltip(
            fields=[region, f'MARKET_SHARE_{peril}'], 
            aliases=[region, f'Market Share {peril}'],
            style=("font-size: 14px;")
        )
    )

    return market_share



# ###############
# def create_3d_choropleth_layer(df_summary_select, s2_select, base_map):
#     # Read the GeoDataFrame
#     S2_X = gpd.read_file(
#         rf"N:\Natural Perils\Data\Geographic\S2 grids\S2_{s2_select}\S2_{s2_select}.gpkg"
#     )
    
#     # If CRS is missing, set it; then reproject if needed:
#     if S2_X.crs is None:
#         S2_X.set_crs(7844, inplace=True)
    
#     # Typically you'd use EPSG:4326 for lat-lon, but if 7844 works for Mapbox, keep it:
#     # Otherwise, do: S2_X = S2_X.to_crs(epsg=4326)
#     S2_X = S2_X.to_crs(7844)
    
#     # Keep only relevant columns, ensure ID is string
#     S2_X = S2_X[['S2_ID', 'geometry']]
#     S2_X['S2_ID'] = S2_X['S2_ID'].astype(str)
#     df_summary_select['S2_ID'] = df_summary_select['S2_ID'].astype(str)
    
#     # Merge data
#     S2_X = S2_X.merge(df_summary_select, on='S2_ID', how='left')
    
#     # Convert to GeoJSON FeatureCollection for Plotly
#     geojson_data = json.loads(S2_X.to_json())

#     # Build the Choroplethmapbox figure
#     fig = go.Figure(go.Choroplethmapbox(
#         geojson=geojson_data,
#         # Use the property name within each GeoJSON feature
#         featureidkey='properties.S2_ID',
#         locations=S2_X['S2_ID'],     # Match with S2_ID
#         z=S2_X['SUM_SI'],           # Colors
#         text=S2_X['TAKE_UP'],       # Will appear in hover
#         colorscale="YlOrRd",
#         marker_opacity=0.5,
#         marker_line_width=0,
#         hoverinfo='location+z+text'
#     ))

#     # Update layout
#     fig.update_layout(
#         mapbox_style="carto-positron",
#         mapbox_zoom=3,
#         mapbox_center={"lat": -28.0, "lon": 134.0},
#         height=600,
#         margin={"r":0, "t":0, "l":0, "b":0}
#     )

#     # Convert Plotly figure to HTML, embed in Folium popup
#     fig_html = fig.to_html(full_html=False)
#     iframe = folium.IFrame(fig_html, width=700, height=500)
#     popup = folium.Popup(iframe, max_width=2650)
#     folium.Marker(location=[-28.0, 134.0], popup=popup).add_to(base_map)

#     return base_map


################################### 






