

# ---- geocode functions -------
# set_geocode_source
# check_GNAF_validity - helper function
# geocode
# enrich_by_region  - used for enriching with SA3 region
# enrich_S2 - adds S2_TK_12


# ---- enrichment functions -------
# enrich_single  - helper function
# enrich



# Geocode functions -------------------------------------------------------------------------


# creates a GEOCODE_KEY ready for matching, from a dataset of correspondences between GNAF and latlongs
# #either postcode CHIP average latlongs, postcode centoid, or lookup postcode default (80th percentile)
def set_geocode_source(geocode):
    # Rename DETAIL_PID to GNAF
    geocode.rename(columns={'DETAIL_PID': 'GNAF'}, inplace=True)
    # If postcode is missing set to 9999
    geocode['POSTCODE'] = geocode['POSTCODE'].fillna(9999).astype(int)
    # Take first row of each GNAF
    geocode = geocode.groupby('GNAF').first().reset_index()
    # Summarize average latitude and longitude by postcode
    geocode_postcode = geocode.groupby('POSTCODE').agg({'LATITUDE': 'mean', 'LONGITUDE': 'mean'}).reset_index()
    geocode_postcode['CONFIDENCE'] = 9
    # Concatenate geocode_postcode to geocode
    geocode = pd.concat([geocode, geocode_postcode], ignore_index=True)
    # Create GEOCODE_KEY
    geocode['GEOCODE_KEY'] = np.where(geocode['GNAF'].isna(),
                                        'POSTCODE_' + geocode['POSTCODE'].astype(str),
                                        geocode['GNAF'])
    return geocode



def check_GNAF_validity(df, geocode, postcode_default="POSTCODE_2000"):
    # Check if GEOCODE_KEY from df is in geocode
    missing_keys = ~df['GEOCODE_KEY'].isin(geocode['GEOCODE_KEY'])
    # Replace GEOCODE_KEY with "POSTCODE_" + POSTCODE if not in geocode
    df.loc[missing_keys, 'GEOCODE_KEY'] = 'POSTCODE_' + df.loc[missing_keys, 'POSTCODE']
    
    num_replacements_1 = missing_keys.sum()

    #if GEOCODE_KEY is still not in geocode, replace with postcode_default
    missing_keys = ~df['GEOCODE_KEY'].isin(geocode['GEOCODE_KEY'])
    df.loc[missing_keys, 'GEOCODE_KEY'] = postcode_default

    num_replacements_2 = missing_keys.sum()
    
    return df, num_replacements_1 + num_replacements_2 



#creates a GEOCODE_KEY for the input dataset and merges it with the geocode - for latlongs
def geocoder(df, geocode, postcode_default="POSTCODE_2000"):

    # 1st step: create GEOCODE_KEY and use postcode for missing gnafs
    df['GNAF'] = df['GNAF'].str.strip().fillna('')
    df['POSTCODE'] = df['POSTCODE'].astype(str).str.strip().fillna('')

    #GEOCODE_KEY = coalesce(GNAF, POSTCODE)
    df['GEOCODE_KEY'] = np.where(df['GNAF'] == '', 
                                'POSTCODE_' + df['POSTCODE'],
                                df['GNAF'])
    
    df, fixes = check_GNAF_validity(df, geocode, postcode_default="POSTCODE_2000")
    print(f"Number of GEOCODE_KEY replacements: {fixes}")

    geocode = geocode.drop(columns=['GNAF'])
    geocode.rename(columns={'POSTCODE':'GEOCODE_POSTCODE'}, inplace=True)

    df = df.merge(geocode, left_on='GEOCODE_KEY', right_on='GEOCODE_KEY', how='left')
    
    # check merge
    missing_latitudes = df[df['LATITUDE'].isnull()]
    return df, missing_latitudes



def geocode_SA3(df):

    if 'index_right' in df.columns:
        df = df.drop(columns=['index_right'])

    gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['LONGITUDE'], df['LATITUDE']))

    sa3 = gpd.read_file(r"N:\Natural Perils\Data\Geographic\ABS\SA3\SA3_2021_AUST_GDA2020.shp")
    sa3 = sa3.rename(columns={"SA3_CODE21": "SA3", "SA3_NAME21": "SA3_NAME"})
    sa3["SA3"] = sa3["SA3"].replace("ZZZZZ", 99999)
    sa3["SA3"] = sa3["SA3"].astype(int)
    sa3 = sa3[["SA3", "SA3_NAME", "geometry"]]

    gdf.sindex
    sa3.sindex
    result_df = gpd.sjoin(gdf, sa3, how="left", predicate='within')

    result_df[result_df["SA3"].isnull()]
    result_df["SA3"] = result_df["SA3"].fillna(99999)
    result_df["SA3"] = result_df["SA3"].astype(int)

    print(result_df.head())

    return result_df


def geocode_postcode(df):

    if 'index_right' in df.columns:
        df = df.drop(columns=['index_right'])

    gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['LONGITUDE'], df['LATITUDE']))

    sa3 = gpd.read_file(r"N:\Natural Perils\Data\Geographic\ABS\nonABS structures\Postcodes\POA_2021_AUST_GDA2020.shp")
    sa3 = sa3.rename(columns={"POA_CODE21": "POSTCODE"})
    sa3["POSTCODE"] = sa3["POSTCODE"].replace("ZZZZ", 9999)
    sa3["POSTCODE"] = sa3["POSTCODE"].astype(int)
    sa3 = sa3[["POSTCODE", "geometry"]]

    gdf.sindex
    sa3.sindex
    result_df = gpd.sjoin(gdf, sa3, how="left", predicate='within')

    result_df[result_df["POSTCODE"].isnull()]
    result_df["POSTCODE"] = result_df["POSTCODE"].fillna(9999)
    result_df["POSTCODE"] = result_df["POSTCODE"].astype(int)

    print(result_df.head())

    return result_df


#all other levels are look ups from the S2_12 level
def geocode_S2_12(df):
    
    df['S2_TK_12'] = df.apply(lambda x: s2sphere.CellId.from_lat_lng(s2sphere.LatLng.from_degrees(x['LATITUDE'], x['LONGITUDE'])).parent(12).to_token(), axis=1)
    
    return df



# enrichment functions -------------------------------------------------------------------------
# for Hazard enrichment, and Accumulation enrichment ------------------------------


def enrich_single(df, map):

    df = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['LONGITUDE'], df['LATITUDE']))
    # Spatial join df and gdf_bf
    #if index_right is in df then delete it
    if 'index_right' in df.columns:
        df = df.drop(columns=['index_right'])
    df_enriched = gpd.sjoin(df, map, how='left')
    df_enriched = df_enriched.drop(columns=['index_right', 'geometry'])
    
    # Check for missing joins
    missing = df_enriched.isnull().sum()
    return df_enriched, missing



def enrich(df, *maps):
    missing_total = pd.Series(dtype=int)
    for map in maps:
        df, missing = enrich_single(df, map)
        missing_total = missing_total.add(missing, fill_value=0)
    return df, missing_total