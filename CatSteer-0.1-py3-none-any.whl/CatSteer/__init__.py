
import datetime
import urllib.request

# Licensing Information
license_key = "ABC123-DEF456"
license_url = "https://raw.githubusercontent.com/CatSteer/licensing-control/main/license.txt"
expiry_date = datetime.datetime(2025, 9, 1)

# Function to Validate License
def validate_license():
    try:
        with urllib.request.urlopen(license_url) as response:
            valid_keys = response.read().decode().splitlines()
            if license_key not in valid_keys:
                raise ValueError("Invalid license key.")
    except Exception as e:
        raise RuntimeError(f"License validation failed: {e}")

    if datetime.datetime.now() > expiry_date:
        raise RuntimeError("License has expired.")

# Execute Validation
validate_license()
